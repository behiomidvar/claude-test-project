/* Every global is read at RENDER time, not at module evaluation. In the compiled
   bundle this file may be evaluated before Screens.jsx assigns window.DTScreens
   (and before the namespace finishes populating), and a top-level destructure
   threw there — leaving App undefined for every consumer of the bundle. */

/* ── Tab bar — OWNED BY THIS KIT ──────────────────────────────────────────
   Deliberately NOT the deleted BottomNav and not a copy of its structure: that
   component's shape did not match the real screens, which is why it was removed.
   Built to the current navigation spec instead:
     · active tab = FLAT var(--nav-active) (brand-lavender-600 light /
       brand-lavender-400 dark) on BOTH icon and label — never --accent, never a
       --gradient-brand pill. Persistent navigation must stay distinct from the
       like/heart action, which owns brand pink. See readme §Bottom tab bar.
     · count badge = the design system's Badge variant="count" (which owns the
       --gradient-brand-strong pill). A count means "needs attention", a different
       meaning from "this is the active item", so it does not collide. Do not
       re-draw the pill here — it used to be a local copy.
     · inactive = --text-subtle; the whole tab is a >=48dp target.
   This kit is now --nav-active's real consumer. */
function TabBar({ value, onChange, items }) {
  const { Badge } = window.DeltalkDesignSystem_288455 || {};
  return (
    <nav style={{ display: 'flex', alignItems: 'stretch', justifyContent: 'space-around',
      background: 'var(--surface-card)', borderTop: '1px solid var(--border-subtle)',
      padding: '6px 6px calc(6px + env(safe-area-inset-bottom,0px))', flexShrink: 0 }}>
      {items.map(it => {
        const on = it.id === value;
        return (
          <button key={it.id} type="button" aria-current={on ? 'page' : undefined}
            onClick={() => onChange(it.id)}
            style={{ flex: 1, minHeight: 'var(--size-48)', display: 'flex', flexDirection: 'column',
              alignItems: 'center', justifyContent: 'center', gap: 4, padding: '4px 2px',
              background: 'none', border: 'none', cursor: 'pointer', fontFamily: 'inherit',
              color: on ? 'var(--nav-active)' : 'var(--text-subtle)',
              transition: 'color var(--dur-fast) var(--ease-standard)' }}>
            <span style={{ position: 'relative', width: 'var(--size-24)', height: 'var(--size-24)', display: 'block' }}>
              {it.icon}
              {it.badge && Badge && (
                <Badge variant="count" style={{ position: 'absolute', insetBlockStart: -7, insetInlineEnd: -11 }}>{it.badge}</Badge>
              )}
            </span>
            <span style={{ fontSize: 'var(--text-micro)', fontWeight: on ? 'var(--fw-bold)' : 'var(--fw-medium)' }}>{it.label}</span>
          </button>
        );
      })}
    </nav>
  );
}

function App() {
  const Icons = window.DeltalkIcons || {};
  const { Onboarding, Discover, Talks, Chat, Profile } = window.DTScreens || {};
  const [onboarded, setOnboarded] = React.useState(false);
  const [tab, setTab] = React.useState('discover');
  const [convo, setConvo] = React.useState(null);

  let screen;
  if (!onboarded) screen = <Onboarding onDone={() => setOnboarded(true)} />;
  else if (convo) screen = <Chat convo={convo} onBack={() => setConvo(null)} />;
  else if (tab === 'discover') screen = <Discover onOpen={(p) => setConvo({ id: 'new', person: p, blur: 12, thread: [{ from: 'them', kind: 'text', text: 'خوشحالم که یه چیزی گفتی — بیشتر آدم‌ها فقط نگاه می‌کنن.', time: 'الان' }] })} />;
  else if (tab === 'talks') screen = <Talks onOpen={setConvo} />;
  else screen = <Profile />;

  const showNav = onboarded && !convo;

  return (
    <div style={{ display: 'flex', flexDirection: 'column', height: '100%', background: 'var(--surface)' }}>
      <div style={{ flex: 1, minHeight: 0, display: 'flex', flexDirection: 'column' }}>{screen}</div>
      {showNav && (
        <TabBar value={tab} onChange={setTab} items={[
          { id: 'talks', label: 'گفتگوها', icon: <Icons.ChatHeart />, badge: '۲' },
          { id: 'discover', label: 'کاوش', icon: <Icons.Compass /> },
          { id: 'you', label: 'تو', icon: <Icons.User /> },
        ]} />
      )}
    </div>
  );
}

/* Phone shell */
function Phone() {
  return (
    /* Desk and bezel are PROTOTYPE CHROME, not app UI: they come from the
       theme-invariant --proto-* family (tokens/proto-chrome.css) because a table
       does not change colour when the app on the phone goes dark. The screen
       inside stays --surface and flips normally. */
    <div style={{ minHeight: '100vh', display: 'flex', alignItems: 'center', justifyContent: 'center', background: 'var(--proto-desk-bg)', padding: 24, boxSizing: 'border-box' }}>
      <div style={{ width: 390, height: 810, background: 'var(--surface)', borderRadius: 46, overflow: 'hidden', position: 'relative',
        boxShadow: 'var(--proto-device-shadow), 0 0 0 11px var(--proto-bezel), 0 0 0 13px var(--proto-bezel-edge)' }}>
        <div style={{ position: 'absolute', top: 0, left: 0, right: 0, height: 34, display: 'flex', alignItems: 'center', justifyContent: 'space-between', padding: '0 26px', zIndex: 50, fontFamily: 'var(--font-sans)', fontSize: 13, fontWeight: 600, color: 'var(--ink)', pointerEvents: 'none' }}>
          <span>۹:۴۱</span>
          <span style={{ display: 'flex', gap: 5, alignItems: 'center' }}>
            <svg width="17" height="11" viewBox="0 0 17 11" fill="currentColor"><rect x="0" y="7" width="3" height="4" rx="1"/><rect x="4" y="5" width="3" height="6" rx="1"/><rect x="8" y="2.5" width="3" height="8.5" rx="1"/><rect x="12" y="0" width="3" height="11" rx="1"/></svg>
            <svg width="22" height="11" viewBox="0 0 24 12" fill="none"><rect x="1" y="1" width="20" height="10" rx="3" stroke="currentColor" strokeWidth="1.2" opacity=".5"/><rect x="2.5" y="2.5" width="15" height="7" rx="1.5" fill="currentColor"/><rect x="22" y="4" width="1.5" height="4" rx="1" fill="currentColor" opacity=".5"/></svg>
          </span>
        </div>
        <div style={{ position: 'absolute', inset: 0, paddingTop: 34 }}>
          <div style={{ height: '100%' }}><App /></div>
        </div>
      </div>
    </div>
  );
}

/* Mount ONLY on this UI kit's own page. This file is also swept into the compiled
   _ds_bundle.js, which every @dsCard loads — several of those cards have their own
   #root, so an unguarded mount would render the phone shell into them. The opt-in
   marker is data-dt-app on the root node (see index.html).

   Mount at most ONE ROOT, but let the LAST copy render into it. This file exists
   twice at runtime on the kit page — once compiled into _ds_bundle.js and once as
   the page's own <script type="text/babel">. A boolean "already mounted" guard made
   the FIRST (bundled, therefore stale) copy win: it mounted a tree that had
   captured the bundle's stale Screens.jsx, and the fresh page-level copy then
   refused to mount, so source fixes never reached the screen. Caching the ROOT and
   re-rendering means the freshest copy always paints, while createRoot still runs
   only once on the node. */
const __dtRoot = document.getElementById('root');
if (__dtRoot && __dtRoot.hasAttribute('data-dt-app')) {
  window.__dtAppRoot = window.__dtAppRoot || ReactDOM.createRoot(__dtRoot);
  window.__dtAppRoot.render(<Phone />);
}
