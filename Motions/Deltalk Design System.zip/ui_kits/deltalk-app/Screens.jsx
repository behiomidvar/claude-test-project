/* Design-system components are resolved at RENDER time, not at module evaluation.
   This file is also compiled into _ds_bundle.js, where it can be evaluated BEFORE
   the component IIFEs have populated the namespace — a top-level destructure then
   captured undefined and Onboarding threw "Element type is invalid". Each name
   below is a thin wrapper that looks its component up when React renders it. */
const dsLazy = (name) => function DSLazy(props) {
  const C = (window.DeltalkDesignSystem_288455 || {})[name];
  return C ? React.createElement(C, props) : null;
};
const Button = dsLazy('Button'), IconButton = dsLazy('IconButton'), Input = dsLazy('Input'),
  Avatar = dsLazy('Avatar'), Badge = dsLazy('Badge'), Chip = dsLazy('Chip'), Card = dsLazy('Card'),
  MessageBubble = dsLazy('MessageBubble'), VoiceNote = dsLazy('VoiceNote'),
  PromptCard = dsLazy('PromptCard'), TypingDots = dsLazy('TypingDots');
/* Icons and demo data resolve the same way. */
const I = new Proxy({}, { get: (_, k) => (window.DeltalkIcons || {})[k] });
const D = () => window.DeltalkData || {};
const toFa = (n) => (D().toFa ? D().toFa(n) : n);

/* ── shared bits ── */
function TopBar({ title, left, right, subtitle }) {
  return (
    <header style={{ display: 'flex', alignItems: 'center', gap: 12, padding: '14px var(--gutter-screen)', minHeight: 60,
      background: 'var(--surface-card)', borderBottom: '1px solid var(--border-subtle)', position: 'sticky', top: 0, zIndex: 5 }}>
      {left}
      <div style={{ flex: 1, minWidth: 0 }}>
        <div style={{ fontFamily: 'var(--font-sans)', fontWeight: 700, fontSize: 18, color: 'var(--ink)' }}>{title}</div>
        {subtitle && <div style={{ fontSize: 12.5, color: 'var(--conversation-active)', display: 'flex', alignItems: 'center', gap: 6 }}>{subtitle}</div>}
      </div>
      {right}
    </header>
  );
}

/* ── Onboarding: words-first entry ── */
function Onboarding({ onDone }) {
  const [answer, setAnswer] = React.useState('');
  return (
    /* Onboarding is a NORMAL themed screen. It used --surface-cool as a full-screen
       wash, which is a dark value in BOTH themes, so the screen stayed dark in light
       mode — and it breaks the rule that cool is a meaning-carrying accent, never a
       page background (the same rule that keeps received bubbles neutral). The cool
       accent now lives only on the eyebrow, the prompt well and the helper line. */
    <div style={{ display: 'flex', flexDirection: 'column', height: '100%', background: 'var(--surface)' }}>
      <div style={{ flex: 1, padding: '52px 26px 24px', display: 'flex', flexDirection: 'column' }}>
        <img className="dt-wm--light" src="../../assets/wordmark-horizontal-light.svg" height="48" alt="دلتاک" style={{ alignSelf: 'flex-start' }} />
        <img className="dt-wm--dark" src="../../assets/wordmark-horizontal-dark.svg" height="48" alt="" aria-hidden="true" style={{ alignSelf: 'flex-start' }} />
        <div style={{ flex: 1 }} />
        <span style={{ fontFamily: 'var(--font-sans)', fontWeight: 600, fontSize: 12, color: 'var(--cool-lavender)', marginBottom: 14 }}>اولین پرسش تو</span>
        <h1 style={{ fontFamily: 'var(--font-display)', fontWeight: 500, fontSize: 32, lineHeight: 1.35, color: 'var(--text-primary)', margin: '0 0 22px' }}>
          دربارهٔ چه چیزی می‌تونی<br />ساعت‌ها حرف بزنی؟
        </h1>
        {/* the prompt well: a themed input surface, not a cool slab */}
        <div style={{ background: 'var(--surface-well)', border: '1px solid var(--border)', borderRadius: 'var(--radius-lg)', padding: 4 }}>
          <textarea value={answer} onChange={e => setAnswer(e.target.value)} rows={4} placeholder="یه چیز واقعی بگو…"
            style={{ width: '100%', border: 'none', background: 'transparent', outline: 'none', resize: 'none', color: 'var(--text-primary)',
              fontFamily: 'var(--font-sans)', fontSize: 16, lineHeight: 1.75, padding: 14, boxSizing: 'border-box', textAlign: 'start', direction: 'rtl' }} />
        </div>
        <p style={{ color: 'var(--text-secondary)', fontSize: 13, margin: '14px 0 0', lineHeight: 1.75 }}>هنوز عکسی نیست. توی دلتاک، آدم‌ها اول کلمه‌هات رو می‌بینن — چهره همان‌طور که حرف می‌زنی واضح می‌شه.</p>
      </div>
      <div style={{ padding: '0 26px 34px' }}>
        <Button variant="gradient" size="lg" block onClick={onDone} disabled={answer.trim().length < 2}>شروع گفت‌وگو</Button>
      </div>
    </div>
  );
}

/* ── Discover: prompt/voice-led cards, photos start soft ── */
function Discover({ onOpen }) {
  const [i, setI] = React.useState(0);
  const p = D().PEOPLE[i % D().PEOPLE.length];
  const next = () => setI(v => v + 1);
  return (
    <div style={{ display: 'flex', flexDirection: 'column', height: '100%' }}>
      <TopBar title="کاوش" right={<IconButton label="فیلترها" variant="ghost"><I.Settings size={22} /></IconButton>} />
      <div style={{ flex: 1, overflowY: 'auto', padding: 'var(--space-5) var(--gutter-screen) var(--gap-section)' }}>
        <Card pad="sm" style={{ padding: 0, overflow: 'hidden', marginBottom: 16 }}>
          <div style={{ position: 'relative' }}>
            <img src={p.photo} alt="" style={{ width: '100%', height: 210, objectFit: 'cover', display: 'block', filter: 'blur(10px)', transform: 'scale(1.06)' }} />
            <div style={{ position: 'absolute', inset: 0, background: 'var(--gradient-media-scrim)' }} />
            <div style={{ position: 'absolute', insetInlineStart: 16, bottom: 14, color: '#fff' }}>
              <div style={{ fontFamily: 'var(--font-sans)', fontWeight: 700, fontSize: 20 }}>{p.name}، {toFa(p.age)}</div>
              <div style={{ fontSize: 13, opacity: .9 }}>{p.city}</div>
            </div>
            <div style={{ position: 'absolute', insetInlineEnd: 12, top: 12 }}><Badge variant="cool"><I.Eye size={13} style={{ marginInlineEnd: 4 }} />با گفت‌وگو واضح می‌شود</Badge></div>
          </div>
          <div style={{ padding: 18 }}>
            <PromptCard question={p.prompt} answer={p.answer} style={{ boxShadow: 'none', border: 'none', padding: 0, background: 'transparent' }} />
            <div style={{ display: 'flex', gap: 'var(--gap-inline)', flexWrap: 'wrap', marginTop: 16 }}>
              {p.interests.map(t => <Chip key={t} interactive={false} variant="cool">{t}</Chip>)}
            </div>
          </div>
        </Card>
        <div style={{ display: 'flex', gap: 12 }}>
          <Button variant="secondary" size="lg" block onClick={next}>الان نه</Button>
          <Button variant="gradient" size="lg" block iconRight={<I.Send size={18} />} onClick={() => onOpen(p)}>شروع گفت‌وگو</Button>
        </div>
      </div>
    </div>
  );
}

/* ── Talks: conversation list ── */
function Talks({ onOpen }) {
  return (
    <div style={{ display: 'flex', flexDirection: 'column', height: '100%' }}>
      <TopBar title="گفتگوها" subtitle={<><TypingDots size="sm" color="var(--conversation-active)" /> ۲ گفت‌وگوی فعال</>} />
      <div style={{ flex: 1, overflowY: 'auto' }}>
        {D().CONVERSATIONS.map(c => (
          <button key={c.id} onClick={() => onOpen(c)} style={{ display: 'flex', gap: 14, alignItems: 'center', width: '100%',
            padding: '14px var(--gutter-screen)', border: 'none', borderBottom: '1px solid var(--border-subtle)', background: 'transparent',
            cursor: 'pointer', textAlign: 'start' }}>
            <Avatar name={c.person.name} src={c.person.photo} size="lg" blur={c.blur} online={c.active} />
            <div style={{ flex: 1, minWidth: 0 }}>
              <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'baseline', gap: 'var(--gap-inline)' }}>
                <span style={{ fontFamily: 'var(--font-sans)', fontWeight: 600, fontSize: 16, color: 'var(--ink)' }}>{c.person.name}</span>
                <span style={{ fontSize: 12, color: 'var(--ink-50)', flexShrink: 0 }}>{c.time}</span>
              </div>
              <div style={{ display: 'flex', justifyContent: 'space-between', gap: 'var(--gap-inline)', marginTop: 3 }}>
                <span style={{ fontSize: 14, color: c.unread ? 'var(--ink)' : 'var(--ink-50)', overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap', fontWeight: c.unread ? 500 : 400 }}>{c.last}</span>
                {c.unread ? <Badge variant="count">{toFa(c.unread)}</Badge> : null}
              </div>
            </div>
          </button>
        ))}
      </div>
    </div>
  );
}

/* ── Chat: the core surface ── */
function Chat({ convo, onBack }) {
  const [msgs, setMsgs] = React.useState(convo.thread);
  const [draft, setDraft] = React.useState('');
  const [playing, setPlaying] = React.useState(false);
  const [showReveal, setShowReveal] = React.useState(false);
  const scroller = React.useRef(null);
  React.useEffect(() => { if (scroller.current) scroller.current.scrollTop = scroller.current.scrollHeight; }, [msgs]);
  const send = () => {
    if (!draft.trim()) return;
    setMsgs(m => [...m, { from: 'me', kind: 'text', text: draft, time: 'الان' }]);
    setDraft('');
    if (msgs.length >= 3) setTimeout(() => setShowReveal(true), 500);
  };
  return (
    <div style={{ display: 'flex', flexDirection: 'column', height: '100%', background: 'var(--surface-well)' }}>
      <TopBar
        left={<IconButton label="بازگشت" variant="ghost" onClick={onBack}><I.Back size={22} /></IconButton>}
        title={convo.person.name}
        subtitle={<><span style={{ width: 7, height: 7, borderRadius: '50%', background: 'var(--conversation-active)', display: 'inline-block' }} /> گفتگوی فعال</>}
        right={<Avatar name={convo.person.name} src={convo.person.photo} size="sm" blur={convo.blur} />} />
      <div ref={scroller} style={{ flex: 1, overflowY: 'auto', padding: 'var(--space-5) var(--gutter-screen)' }}>
        <div style={{ textAlign: 'center', marginBottom: 16 }}>
          <Badge variant="neutral">با یک پرسش به هم رسیدید · چهره را با گفت‌وگو به دست بیار</Badge>
        </div>
        {msgs.map((m, k) => m.kind === 'voice'
          ? <div key={k} style={{ display: 'flex', justifyContent: m.from === 'me' ? 'flex-end' : 'flex-start', marginBottom: 8 }}><VoiceNote from={m.from} duration={m.duration} playing={playing} onToggle={() => setPlaying(v => !v)} /></div>
          : <MessageBubble key={k} from={m.from} time={m.time}>{m.text}</MessageBubble>)}
        {showReveal && (
          <Card variant="gradient" style={{ marginTop: 12, textAlign: 'center' }}>
            <div style={{ fontFamily: 'var(--font-display)', fontSize: 20, marginBottom: 6 }}>عکسشون یه‌کم واضح‌تر شد.</div>
            <div style={{ fontSize: 13, opacity: .9 }}>به حرف زدن ادامه بده — دارید همدیگه رو می‌شناسید.</div>
          </Card>
        )}
      </div>
      <div style={{ display: 'flex', gap: 10, alignItems: 'center', padding: '12px 14px calc(12px + env(safe-area-inset-bottom,0px))', background: 'var(--surface-card)', borderTop: '1px solid var(--border-subtle)' }}>
        <IconButton label="ضبط پیام صوتی" variant="ghost"><I.Mic size={22} /></IconButton>
        <div style={{ flex: 1, background: 'var(--surface-well)', borderRadius: 999, display: 'flex', alignItems: 'center', paddingInlineStart: 16, paddingInlineEnd: 6 }}>
          <input value={draft} onChange={e => setDraft(e.target.value)} onKeyDown={e => e.key === 'Enter' && send()} placeholder="یه چیز واقعی بگو…"
            style={{ flex: 1, border: 'none', background: 'transparent', outline: 'none', fontFamily: 'var(--font-sans)', fontSize: 15, padding: '12px 0', color: 'var(--ink)', textAlign: 'start' }} />
        </div>
        <IconButton label="ارسال" variant="solid" shape="circle" onClick={send}><I.Send size={20} /></IconButton>
      </div>
    </div>
  );
}

/* ── Profile (You) ── */
function Profile() {
  const me = { name: 'تو', age: 46, city: 'تهران' };
  return (
    <div style={{ display: 'flex', flexDirection: 'column', height: '100%' }}>
      <TopBar title="تو" right={<IconButton label="تنظیمات" variant="ghost"><I.Settings size={22} /></IconButton>} />
      <div style={{ flex: 1, overflowY: 'auto', padding: 'var(--space-5) var(--gutter-screen) var(--gap-section)' }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 16, marginBottom: 20 }}>
          <Avatar name="تو" size="xl" ring />
          <div>
            <div style={{ fontFamily: 'var(--font-sans)', fontWeight: 700, fontSize: 22, color: 'var(--ink)' }}>{me.name}، {toFa(me.age)}</div>
            <div style={{ color: 'var(--ink-70)', fontSize: 14, marginBottom: 8 }}>{me.city}</div>
            <Badge variant="success"><I.Check size={13} style={{ marginInlineEnd: 4 }} />تأییدشده</Badge>
          </div>
        </div>
        <div style={{ fontFamily: 'var(--font-sans)', fontWeight: 600, fontSize: 12, color: 'var(--ink-50)', margin: '6px 0 12px' }}>پرسش‌های تو</div>
        <div style={{ display: 'flex', flexDirection: 'column', gap: 'var(--gap-card)', marginBottom: 22 }}>
          <PromptCard question="دربارهٔ چه چیزی می‌تونی ساعت‌ها حرف بزنی؟" answer="فیلم‌هایی که هیچ‌کس ندیده، و اینکه چرا مادربزرگم دربارهٔ همه‌چیز حق داشت." />
          <PromptCard question="این هفته چه چیز کوچکی خوشحالت کرد؟" />
        </div>
        <Card variant="cool" style={{ display: 'flex', gap: 14, alignItems: 'center' }}>
          <I.Shield size={26} />
          <div>
            <div style={{ fontWeight: 600, fontSize: 15 }}>امنیت به‌صورت پیش‌فرض</div>
            <div style={{ fontSize: 13, opacity: .85, marginTop: 2, lineHeight: 1.75 }}>گزارش، مسدودسازی و رضایت برای عکس همیشه یک لمس فاصله دارند.</div>
          </div>
        </Card>
      </div>
    </div>
  );
}

Object.assign(window, { DTScreens: { Onboarding, Discover, Talks, Chat, Profile }, DTTopBar: TopBar });
