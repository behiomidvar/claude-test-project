# Deltalk App — UI Kit

Interactive, high-fidelity recreation of the Deltalk mobile app (conversation-first connection app). Built entirely from the Deltalk design-system primitives — no re-implemented components.

## Run
Open `index.html`. It loads React + the compiled `_ds_bundle.js`, then the kit scripts. Because the screens read `window.DeltalkDesignSystem_288455`, the bundle must be compiled (it is, at end of each turn).

## Flow (click-through)
1. **Onboarding** — words-first: answer a prompt before you ever see a photo grid. "Start talking" unlocks the app.
2. **Discover** — prompt/voice-led profile cards; the photo starts *blurred* ("earn the face by having the conversation"). Not now / Start talking.
3. **Talks** — conversation list; avatars carry per-conversation blur that would clear as you talk; live "conversation active" dots.
4. **Chat** — the core surface: warm bubbles (you), cool bubbles (them), voice notes, typing indicator, and a "their photo just cleared" reveal after a few messages.
5. **You** — profile led by prompts, plus a "Safety by default" card.

## Files
- `index.html` — loader + `@dsCard` tile.
- `Data.jsx` — fake people / conversations (`window.DeltalkData`), age-diverse, Persian-first content.
- `Screens.jsx` — Onboarding, Discover, Talks, Chat, Profile (`window.DTScreens`).
- `App.jsx` — phone shell, tab-bar routing. The tab bar is an inline component owned by this kit (flat `--nav-active` for the active tab, `--gradient-brand-strong` count badges); the former `BottomNav` design-system component was deleted because its structure did not match these screens.

## Notes
- **RTL / Persian-first.** This kit is now fully Persian and RTL (`dir="rtl"`, `lang="fa"`). Layout uses logical properties; directional icons (`Icons.Back`, `Icons.Send`) mirror via `data-dir-icon`. Numbers are Persian digits (`toFa()` in `Data.jsx`).
- The one hero-gradient rule is respected: at most one gradient moment per screen (the primary CTA / reveal card).
