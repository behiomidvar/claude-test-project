/* @ds-bundle: {"format":4,"namespace":"DesignSystem_a1d7f7","components":[{"name":"Avatar","sourcePath":"components/core/Avatar.jsx"},{"name":"Badge","sourcePath":"components/core/Badge.jsx"},{"name":"Button","sourcePath":"components/core/Button.jsx"},{"name":"Card","sourcePath":"components/core/Card.jsx"},{"name":"Chip","sourcePath":"components/core/Chip.jsx"},{"name":"GradientIcon","sourcePath":"components/core/GradientIcon.jsx"},{"name":"Input","sourcePath":"components/core/Input.jsx"},{"name":"Switch","sourcePath":"components/core/Switch.jsx"},{"name":"TabBar","sourcePath":"components/navigation/TabBar.jsx"}],"sourceHashes":{"components/core/Avatar.jsx":"93a5f281416e","components/core/Badge.jsx":"1fd94ad50763","components/core/Button.jsx":"d5bea94a4270","components/core/Card.jsx":"a86da266c2bb","components/core/Chip.jsx":"30e25fd12750","components/core/GradientIcon.jsx":"c983675dbb91","components/core/Input.jsx":"fe0a423f6c0f","components/core/Switch.jsx":"3eccb44a3ae4","components/navigation/TabBar.jsx":"3438286e2823","guidelines/tweaks-panel.jsx":"d259e3a86f73","ui_kits/deltalk-app/App.jsx":"27268f9a41ac","ui_kits/deltalk-app/Chat.jsx":"1826208bd65d","ui_kits/deltalk-app/Chats.jsx":"4a2536ddd9b5","ui_kits/deltalk-app/Discover.jsx":"a0e055f9e459","ui_kits/deltalk-app/PhoneAuth.jsx":"2241885f7a8a","ui_kits/deltalk-app/Profile.jsx":"1df2d483e936","ui_kits/deltalk-app/data.js":"aa1d96756d1c","ui_kits/deltalk-app/icons.jsx":"b8d335faf9a7"},"inlinedExternals":[],"unexposedExports":[]} */

(() => {

const __ds_ns = (window.DesignSystem_a1d7f7 = window.DesignSystem_a1d7f7 || {});

const __ds_scope = {};

(__ds_ns.__errors = __ds_ns.__errors || []);

// components/core/Avatar.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/**
 * Circular avatar. `ring` draws a gradient border (new-match indicator).
 * Pass `src` for a photo, or `children`/`initials` as a fallback.
 */
function Avatar({
  src,
  initials,
  size = 48,
  ring = false,
  online = false,
  style,
  ...rest
}) {
  const inner = /*#__PURE__*/React.createElement("div", {
    style: {
      width: size,
      height: size,
      borderRadius: "50%",
      overflow: "hidden",
      background: "var(--surface-card)",
      border: "0.5px solid var(--border-subtle)",
      display: "flex",
      alignItems: "center",
      justifyContent: "center",
      fontFamily: "var(--font-family)",
      fontWeight: "var(--fw-medium)",
      fontSize: size * 0.38,
      color: "var(--text-secondary)"
    }
  }, src ? /*#__PURE__*/React.createElement("img", {
    src: src,
    alt: "",
    style: {
      width: "100%",
      height: "100%",
      objectFit: "cover"
    }
  }) : initials);
  return /*#__PURE__*/React.createElement("div", _extends({
    style: {
      position: "relative",
      display: "inline-block",
      ...style
    }
  }, rest), ring ? /*#__PURE__*/React.createElement("div", {
    style: {
      padding: 2.5,
      borderRadius: "50%",
      background: "var(--gradient-accent)"
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      padding: 2,
      borderRadius: "50%",
      background: "var(--bg)"
    }
  }, inner)) : inner, online && /*#__PURE__*/React.createElement("span", {
    style: {
      position: "absolute",
      bottom: 1,
      insetInlineStart: 1,
      width: size * 0.24,
      height: size * 0.24,
      borderRadius: "50%",
      background: "var(--gradient-accent)",
      boxShadow: "0 0 0 2px var(--bg)"
    }
  }));
}
Object.assign(__ds_scope, { Avatar });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/Avatar.jsx", error: String((e && e.message) || e) }); }

// components/core/Badge.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/**
 * Small notification badge / count pill. Filled with the logo gradient (accent-sanctioned).
 * Use `dot` for a bare indicator, or pass a count as children.
 */
function Badge({
  dot = false,
  children,
  style,
  ...rest
}) {
  if (dot) {
    return /*#__PURE__*/React.createElement("span", _extends({
      style: {
        display: "inline-block",
        width: 10,
        height: 10,
        borderRadius: "50%",
        background: "var(--gradient-accent)",
        boxShadow: "0 0 0 2px var(--bg)",
        ...style
      }
    }, rest));
  }
  return /*#__PURE__*/React.createElement("span", _extends({
    style: {
      display: "inline-flex",
      alignItems: "center",
      justifyContent: "center",
      minWidth: 18,
      height: 18,
      padding: "0 5px",
      borderRadius: 999,
      background: "var(--gradient-accent)",
      color: "#FFFFFF",
      fontFamily: "var(--font-family)",
      fontSize: "11px",
      fontWeight: "var(--fw-bold)",
      lineHeight: 1,
      ...style
    }
  }, rest), children);
}
Object.assign(__ds_scope, { Badge });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/Badge.jsx", error: String((e && e.message) || e) }); }

// components/core/Button.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/**
 * Deltalk primary action button. The highest-contrast solid element on a screen —
 * charcoal on light, near-white on dark. Never filled with the logo gradient.
 */
function Button({
  variant = "primary",
  size = "md",
  fullWidth = true,
  disabled = false,
  leadingIcon = null,
  trailingIcon = null,
  onClick,
  children,
  style,
  ...rest
}) {
  const heights = {
    sm: 40,
    md: 52,
    lg: 56
  };
  const pads = {
    sm: "0 16px",
    md: "0 20px",
    lg: "0 24px"
  };
  const base = {
    display: "inline-flex",
    alignItems: "center",
    justifyContent: "center",
    gap: "var(--element-gap)",
    height: heights[size],
    padding: pads[size],
    width: fullWidth ? "100%" : "auto",
    borderRadius: "var(--radius-button)",
    fontFamily: "var(--font-family)",
    fontSize: size === "sm" ? "var(--fs-label)" : "var(--fs-body)",
    fontWeight: "var(--fw-medium)",
    cursor: disabled ? "not-allowed" : "pointer",
    opacity: disabled ? 0.4 : 1,
    border: "0.5px solid transparent",
    transition: "transform var(--dur-press) var(--ease-out), background var(--dur-theme) ease, opacity var(--dur-theme) ease",
    userSelect: "none"
  };
  const variants = {
    primary: {
      background: "var(--cta-bg)",
      color: "var(--cta-text)",
      borderColor: "var(--cta-bg)",
      hoverBg: "var(--cta-hover)"
    },
    secondary: {
      background: "var(--surface-card)",
      color: "var(--text-primary)",
      borderColor: "var(--border-subtle)",
      hoverBg: "var(--bg-subtle)",
      hoverBorder: "var(--border-strong)"
    },
    ghost: {
      background: "transparent",
      color: "var(--text-primary)",
      borderColor: "var(--border-subtle)",
      hoverBg: "var(--bg-subtle)",
      hoverBorder: "var(--border-strong)"
    }
  };
  const {
    hoverBg,
    hoverBorder,
    ...vstyle
  } = variants[variant];
  const enter = e => {
    if (disabled) return;
    if (hoverBg) e.currentTarget.style.background = hoverBg;
    if (hoverBorder) e.currentTarget.style.borderColor = hoverBorder;
  };
  const leave = e => {
    e.currentTarget.style.transform = "scale(1)";
    e.currentTarget.style.background = vstyle.background;
    e.currentTarget.style.borderColor = vstyle.borderColor;
  };
  const press = e => {
    if (!disabled) e.currentTarget.style.transform = "scale(0.97)";
  };
  const release = e => {
    e.currentTarget.style.transform = "scale(1)";
  };
  return /*#__PURE__*/React.createElement("button", _extends({
    type: "button",
    disabled: disabled,
    onClick: onClick,
    onPointerDown: press,
    onPointerUp: release,
    onPointerEnter: enter,
    onPointerLeave: leave,
    style: {
      ...base,
      ...vstyle,
      ...style
    }
  }, rest), leadingIcon, children, trailingIcon);
}
Object.assign(__ds_scope, { Button });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/Button.jsx", error: String((e && e.message) || e) }); }

// components/core/Card.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/**
 * Deltalk surface card. Very light gray (light) / dark charcoal (dark),
 * 20px radius, hairline border, 16px padding.
 */
function Card({
  padding = "var(--card-padding)",
  elevated = false,
  onClick,
  children,
  style,
  ...rest
}) {
  return /*#__PURE__*/React.createElement("div", _extends({
    onClick: onClick,
    style: {
      background: "var(--surface-card)",
      border: "0.5px solid var(--border-subtle)",
      borderRadius: "var(--radius-card)",
      padding,
      boxShadow: elevated ? "var(--shadow-md)" : "none",
      cursor: onClick ? "pointer" : "default",
      ...style
    }
  }, rest), children);
}
Object.assign(__ds_scope, { Card });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/Card.jsx", error: String((e && e.message) || e) }); }

// components/core/Chip.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/**
 * Deltalk chip / tag. Unselected = card surface with hairline border and secondary text.
 * Selected = gold→pink 135° gradient with white text and no border (identical both themes).
 */
function Chip({
  selected = false,
  leadingIcon = null,
  onClick,
  children,
  style,
  ...rest
}) {
  const base = {
    display: "inline-flex",
    alignItems: "center",
    gap: "6px",
    height: 34,
    padding: "0 14px",
    borderRadius: "var(--radius-chip)",
    fontFamily: "var(--font-family)",
    fontSize: "var(--fs-label)",
    fontWeight: "var(--fw-medium)",
    cursor: "pointer",
    userSelect: "none",
    transition: "background var(--dur-theme) ease, color var(--dur-theme) ease",
    whiteSpace: "nowrap"
  };
  const skin = selected ? {
    background: "var(--gradient-chip)",
    color: "#FFFFFF",
    border: "0.5px solid transparent"
  } : {
    background: "var(--surface-card)",
    color: "var(--text-secondary)",
    border: "0.5px solid var(--border-subtle)"
  };
  return /*#__PURE__*/React.createElement("button", _extends({
    type: "button",
    onClick: onClick,
    style: {
      ...base,
      ...skin,
      ...style
    }
  }, rest), leadingIcon, children);
}
Object.assign(__ds_scope, { Chip });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/Chip.jsx", error: String((e && e.message) || e) }); }

// components/core/GradientIcon.jsx
try { (() => {
/**
 * Paints a Lucide-style SVG icon's stroke with a Deltalk logo gradient.
 * Works with a raw <svg> element or an icon component that forwards a `stroke` prop.
 * Use only for active/branded states (per accent rules).
 */
function GradientIcon({
  icon,
  size = 22,
  from = "#F24C9A",
  to = "#BB48F8",
  style
}) {
  const gid = "dtg-" + React.useId().replace(/:/g, "");
  if (!icon) return null;
  return /*#__PURE__*/React.createElement("span", {
    style: {
      display: "inline-flex",
      lineHeight: 0,
      ...style
    }
  }, /*#__PURE__*/React.createElement("svg", {
    width: "0",
    height: "0",
    style: {
      position: "absolute"
    },
    "aria-hidden": "true"
  }, /*#__PURE__*/React.createElement("defs", null, /*#__PURE__*/React.createElement("linearGradient", {
    id: gid,
    x1: "0",
    y1: "0",
    x2: "1",
    y2: "1"
  }, /*#__PURE__*/React.createElement("stop", {
    offset: "0",
    stopColor: from
  }), /*#__PURE__*/React.createElement("stop", {
    offset: "1",
    stopColor: to
  })))), React.cloneElement(icon, {
    width: size,
    height: size,
    size,
    stroke: `url(#${gid})`
  }));
}
Object.assign(__ds_scope, { GradientIcon });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/GradientIcon.jsx", error: String((e && e.message) || e) }); }

// components/core/Input.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/**
 * Deltalk text input. Card-surface fill, 12px radius, 48px tall, hairline border
 * that thickens to 1.5px pink on focus.
 */
function Input({
  label = null,
  hint = null,
  error = null,
  leadingIcon = null,
  trailingIcon = null,
  value,
  onChange,
  placeholder,
  type = "text",
  disabled = false,
  style,
  ...rest
}) {
  const [focused, setFocused] = React.useState(false);
  const wrap = {
    display: "flex",
    alignItems: "center",
    gap: "var(--element-gap)",
    height: 48,
    padding: "0 14px",
    background: "var(--surface-card)",
    borderRadius: "var(--radius-input)",
    border: error ? "1.5px solid var(--brand-pink)" : focused ? "1.5px solid var(--brand-pink)" : "0.5px solid var(--border-subtle)",
    transition: "border-color var(--dur-theme) ease",
    opacity: disabled ? 0.5 : 1
  };
  const input = {
    flex: 1,
    minWidth: 0,
    border: "none",
    outline: "none",
    background: "transparent",
    fontFamily: "var(--font-family)",
    fontSize: "var(--fs-body)",
    color: "var(--text-primary)",
    direction: "rtl",
    textAlign: "right"
  };
  return /*#__PURE__*/React.createElement("label", {
    style: {
      display: "block",
      width: "100%",
      ...style
    }
  }, label && /*#__PURE__*/React.createElement("span", {
    style: {
      display: "block",
      marginBottom: 6,
      fontSize: "var(--fs-label)",
      fontWeight: "var(--fw-medium)",
      color: "var(--text-primary)"
    }
  }, label), /*#__PURE__*/React.createElement("div", {
    style: wrap
  }, leadingIcon, /*#__PURE__*/React.createElement("input", _extends({
    style: input,
    value: value,
    onChange: onChange,
    placeholder: placeholder,
    type: type,
    disabled: disabled,
    onFocus: () => setFocused(true),
    onBlur: () => setFocused(false)
  }, rest)), trailingIcon), (hint || error) && /*#__PURE__*/React.createElement("span", {
    style: {
      display: "block",
      marginTop: 6,
      fontSize: "var(--fs-caption)",
      color: error ? "var(--brand-pink)" : "var(--text-secondary)"
    }
  }, error || hint));
}
Object.assign(__ds_scope, { Input });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/Input.jsx", error: String((e && e.message) || e) }); }

// components/core/Switch.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/**
 * Deltalk toggle switch. On-state track uses the pink→purple logo gradient with a white thumb.
 */
function Switch({
  checked = false,
  onChange,
  disabled = false,
  style,
  ...rest
}) {
  const toggle = () => {
    if (!disabled && onChange) onChange(!checked);
  };
  return /*#__PURE__*/React.createElement("button", _extends({
    type: "button",
    role: "switch",
    "aria-checked": checked,
    disabled: disabled,
    onClick: toggle,
    style: {
      position: "relative",
      width: 48,
      height: 28,
      flex: "0 0 auto",
      borderRadius: 999,
      border: "none",
      padding: 0,
      cursor: disabled ? "not-allowed" : "pointer",
      opacity: disabled ? 0.5 : 1,
      background: checked ? "var(--gradient-accent)" : "var(--border-subtle)",
      transition: "background var(--dur-theme) ease",
      ...style
    }
  }, rest), /*#__PURE__*/React.createElement("span", {
    style: {
      position: "absolute",
      top: 3,
      left: checked ? 23 : 3,
      width: 22,
      height: 22,
      borderRadius: "50%",
      background: "#FFFFFF",
      boxShadow: "var(--shadow-sm)",
      transition: "left var(--dur-theme) var(--ease-out)"
    }
  }));
}
Object.assign(__ds_scope, { Switch });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/Switch.jsx", error: String((e && e.message) || e) }); }

// components/navigation/TabBar.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/**
 * Deltalk bottom tab bar. Active icon painted with the logo gradient; inactive icons hint-gray.
 * items: [{ key, label, icon }] where icon is a Lucide <svg> element.
 */
function TabBar({
  items = [],
  active,
  onChange,
  style,
  ...rest
}) {
  return /*#__PURE__*/React.createElement("nav", _extends({
    style: {
      display: "flex",
      alignItems: "stretch",
      justifyContent: "space-around",
      background: "var(--bg)",
      borderTop: "0.5px solid var(--border-subtle)",
      padding: "8px 8px calc(8px + env(safe-area-inset-bottom))",
      ...style
    }
  }, rest), items.map(it => {
    const isActive = it.key === active;
    return /*#__PURE__*/React.createElement("button", {
      key: it.key,
      type: "button",
      onClick: () => onChange && onChange(it.key),
      style: {
        flex: 1,
        display: "flex",
        flexDirection: "column",
        alignItems: "center",
        gap: 4,
        minHeight: 44,
        padding: "6px 4px",
        border: "none",
        background: "transparent",
        cursor: "pointer",
        fontFamily: "var(--font-family)"
      }
    }, isActive ? /*#__PURE__*/React.createElement(__ds_scope.GradientIcon, {
      icon: it.icon,
      size: 24
    }) : React.cloneElement(it.icon, {
      width: 24,
      height: 24,
      size: 24,
      stroke: "var(--text-hint)",
      style: {
        display: "block"
      }
    }), /*#__PURE__*/React.createElement("span", {
      style: {
        fontSize: "11px",
        fontWeight: isActive ? "var(--fw-medium)" : "var(--fw-regular)",
        color: isActive ? "var(--text-primary)" : "var(--text-hint)"
      }
    }, it.label));
  }));
}
Object.assign(__ds_scope, { TabBar });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/navigation/TabBar.jsx", error: String((e && e.message) || e) }); }

// guidelines/tweaks-panel.jsx
try { (() => {
// @ds-adherence-ignore -- omelette starter scaffold (raw elements/hex/px by design)
// Copied omelette starter. Re-running copy_starter_component with this kind overwrites this file with the latest version (page content is unaffected).

/* BEGIN USAGE */
// tweaks-panel.jsx
// Reusable Tweaks shell + form-control helpers.
// Exports (to window): useTweaks, TweaksPanel, TweakSection, TweakRow, TweakSlider,
//   TweakToggle, TweakRadio, TweakSelect, TweakText, TweakNumber, TweakColor, TweakButton.
//
// Owns the host protocol (listens for __activate_edit_mode / __deactivate_edit_mode,
// posts __edit_mode_available / __edit_mode_set_keys / __edit_mode_dismissed) so
// individual prototypes don't re-roll it. Ships a consistent set of controls so you
// don't hand-draw <input type="range">, segmented radios, steppers, etc.
//
// Usage (in an HTML file that loads React + Babel):
//
//   const TWEAK_DEFAULTS = /*EDITMODE-BEGIN*/{
//     "primaryColor": "#D97757",
//     "palette": ["#D97757", "#29261b", "#f6f4ef"],
//     "fontSize": 16,
//     "density": "regular",
//     "dark": false
//   }/*EDITMODE-END*/;
//
//   function App() {
//     const [t, setTweak] = useTweaks(TWEAK_DEFAULTS);
//     return (
//       <div style={{ fontSize: t.fontSize, color: t.primaryColor }}>
//         Hello
//         <TweaksPanel>
//           <TweakSection label="Typography" />
//           <TweakSlider label="Font size" value={t.fontSize} min={10} max={32} unit="px"
//                        onChange={(v) => setTweak('fontSize', v)} />
//           <TweakRadio  label="Density" value={t.density}
//                        options={['compact', 'regular', 'comfy']}
//                        onChange={(v) => setTweak('density', v)} />
//           <TweakSection label="Theme" />
//           <TweakColor  label="Primary" value={t.primaryColor}
//                        options={['#D97757', '#2A6FDB', '#1F8A5B', '#7A5AE0']}
//                        onChange={(v) => setTweak('primaryColor', v)} />
//           <TweakColor  label="Palette" value={t.palette}
//                        options={[['#D97757', '#29261b', '#f6f4ef'],
//                                  ['#475569', '#0f172a', '#f1f5f9']]}
//                        onChange={(v) => setTweak('palette', v)} />
//           <TweakToggle label="Dark mode" value={t.dark}
//                        onChange={(v) => setTweak('dark', v)} />
//         </TweaksPanel>
//       </div>
//     );
//   }
//
// TweakRadio is the segmented control for 2–3 short options (auto-falls-back to
// TweakSelect past ~16/~10 chars per label); reach for TweakSelect directly when
// options are many or long. For color tweaks always curate 3-4 options rather than
// a free picker; an option can also be a whole 2–5 color palette (the stored value
// is the array). The Tweak* controls are a floor, not a ceiling — build custom
// controls inside the panel if a tweak calls for UI they don't cover.
/* END USAGE */
// ─────────────────────────────────────────────────────────────────────────────

const __TWEAKS_STYLE = `
  .twk-panel{position:fixed;right:16px;bottom:16px;z-index:2147483646;width:280px;
    max-height:calc(100vh - 32px);display:flex;flex-direction:column;
    transform:scale(var(--dc-inv-zoom,1));transform-origin:bottom right;
    background:rgba(250,249,247,.78);color:#29261b;
    -webkit-backdrop-filter:blur(24px) saturate(160%);backdrop-filter:blur(24px) saturate(160%);
    border:.5px solid rgba(255,255,255,.6);border-radius:14px;
    box-shadow:0 1px 0 rgba(255,255,255,.5) inset,0 12px 40px rgba(0,0,0,.18);
    font:11.5px/1.4 ui-sans-serif,system-ui,-apple-system,sans-serif;overflow:hidden}
  .twk-hd{display:flex;align-items:center;justify-content:space-between;
    padding:10px 8px 10px 14px;cursor:move;user-select:none}
  .twk-hd b{font-size:12px;font-weight:600;letter-spacing:.01em}
  .twk-x{appearance:none;border:0;background:transparent;color:rgba(41,38,27,.55);
    width:22px;height:22px;border-radius:6px;cursor:default;font-size:13px;line-height:1}
  .twk-x:hover{background:rgba(0,0,0,.06);color:#29261b}
  .twk-body{padding:2px 14px 14px;display:flex;flex-direction:column;gap:10px;
    overflow-y:auto;overflow-x:hidden;min-height:0;
    scrollbar-width:thin;scrollbar-color:rgba(0,0,0,.15) transparent}
  .twk-body::-webkit-scrollbar{width:8px}
  .twk-body::-webkit-scrollbar-track{background:transparent;margin:2px}
  .twk-body::-webkit-scrollbar-thumb{background:rgba(0,0,0,.15);border-radius:4px;
    border:2px solid transparent;background-clip:content-box}
  .twk-body::-webkit-scrollbar-thumb:hover{background:rgba(0,0,0,.25);
    border:2px solid transparent;background-clip:content-box}
  .twk-row{display:flex;flex-direction:column;gap:5px}
  .twk-row-h{flex-direction:row;align-items:center;justify-content:space-between;gap:10px}
  .twk-lbl{display:flex;justify-content:space-between;align-items:baseline;
    color:rgba(41,38,27,.72)}
  .twk-lbl>span:first-child{font-weight:500}
  .twk-val{color:rgba(41,38,27,.5);font-variant-numeric:tabular-nums}

  .twk-sect{font-size:10px;font-weight:600;letter-spacing:.06em;text-transform:uppercase;
    color:rgba(41,38,27,.45);padding:10px 0 0}
  .twk-sect:first-child{padding-top:0}

  .twk-field{appearance:none;box-sizing:border-box;width:100%;min-width:0;height:26px;padding:0 8px;
    border:.5px solid rgba(0,0,0,.1);border-radius:7px;
    background:rgba(255,255,255,.6);color:inherit;font:inherit;outline:none}
  .twk-field:focus{border-color:rgba(0,0,0,.25);background:rgba(255,255,255,.85)}
  select.twk-field{padding-right:22px;
    background-image:url("data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='10' height='6' viewBox='0 0 10 6'><path fill='rgba(0,0,0,.5)' d='M0 0h10L5 6z'/></svg>");
    background-repeat:no-repeat;background-position:right 8px center}

  .twk-slider{appearance:none;-webkit-appearance:none;width:100%;height:4px;margin:6px 0;
    border-radius:999px;background:rgba(0,0,0,.12);outline:none}
  .twk-slider::-webkit-slider-thumb{-webkit-appearance:none;appearance:none;
    width:14px;height:14px;border-radius:50%;background:#fff;
    border:.5px solid rgba(0,0,0,.12);box-shadow:0 1px 3px rgba(0,0,0,.2);cursor:default}
  .twk-slider::-moz-range-thumb{width:14px;height:14px;border-radius:50%;
    background:#fff;border:.5px solid rgba(0,0,0,.12);box-shadow:0 1px 3px rgba(0,0,0,.2);cursor:default}

  .twk-seg{position:relative;display:flex;padding:2px;border-radius:8px;
    background:rgba(0,0,0,.06);user-select:none}
  .twk-seg-thumb{position:absolute;top:2px;bottom:2px;border-radius:6px;
    background:rgba(255,255,255,.9);box-shadow:0 1px 2px rgba(0,0,0,.12);
    transition:left .15s cubic-bezier(.3,.7,.4,1),width .15s}
  .twk-seg.dragging .twk-seg-thumb{transition:none}
  .twk-seg button{appearance:none;position:relative;z-index:1;flex:1;border:0;
    background:transparent;color:inherit;font:inherit;font-weight:500;min-height:22px;
    border-radius:6px;cursor:default;padding:4px 6px;line-height:1.2;
    overflow-wrap:anywhere}

  .twk-toggle{position:relative;width:32px;height:18px;border:0;border-radius:999px;
    background:rgba(0,0,0,.15);transition:background .15s;cursor:default;padding:0}
  .twk-toggle[data-on="1"]{background:#34c759}
  .twk-toggle i{position:absolute;top:2px;left:2px;width:14px;height:14px;border-radius:50%;
    background:#fff;box-shadow:0 1px 2px rgba(0,0,0,.25);transition:transform .15s}
  .twk-toggle[data-on="1"] i{transform:translateX(14px)}

  .twk-num{display:flex;align-items:center;box-sizing:border-box;min-width:0;height:26px;padding:0 0 0 8px;
    border:.5px solid rgba(0,0,0,.1);border-radius:7px;background:rgba(255,255,255,.6)}
  .twk-num-lbl{font-weight:500;color:rgba(41,38,27,.6);cursor:ew-resize;
    user-select:none;padding-right:8px}
  .twk-num input{flex:1;min-width:0;height:100%;border:0;background:transparent;
    font:inherit;font-variant-numeric:tabular-nums;text-align:right;padding:0 8px 0 0;
    outline:none;color:inherit;-moz-appearance:textfield}
  .twk-num input::-webkit-inner-spin-button,.twk-num input::-webkit-outer-spin-button{
    -webkit-appearance:none;margin:0}
  .twk-num-unit{padding-right:8px;color:rgba(41,38,27,.45)}

  .twk-btn{appearance:none;height:26px;padding:0 12px;border:0;border-radius:7px;
    background:rgba(0,0,0,.78);color:#fff;font:inherit;font-weight:500;cursor:default}
  .twk-btn:hover{background:rgba(0,0,0,.88)}
  .twk-btn.secondary{background:rgba(0,0,0,.06);color:inherit}
  .twk-btn.secondary:hover{background:rgba(0,0,0,.1)}

  .twk-swatch{appearance:none;-webkit-appearance:none;width:56px;height:22px;
    border:.5px solid rgba(0,0,0,.1);border-radius:6px;padding:0;cursor:default;
    background:transparent;flex-shrink:0}
  .twk-swatch::-webkit-color-swatch-wrapper{padding:0}
  .twk-swatch::-webkit-color-swatch{border:0;border-radius:5.5px}
  .twk-swatch::-moz-color-swatch{border:0;border-radius:5.5px}

  .twk-chips{display:flex;gap:6px}
  .twk-chip{position:relative;appearance:none;flex:1;min-width:0;height:46px;
    padding:0;border:0;border-radius:6px;overflow:hidden;cursor:default;
    box-shadow:0 0 0 .5px rgba(0,0,0,.12),0 1px 2px rgba(0,0,0,.06);
    transition:transform .12s cubic-bezier(.3,.7,.4,1),box-shadow .12s}
  .twk-chip:hover{transform:translateY(-1px);
    box-shadow:0 0 0 .5px rgba(0,0,0,.18),0 4px 10px rgba(0,0,0,.12)}
  .twk-chip[data-on="1"]{box-shadow:0 0 0 1.5px rgba(0,0,0,.85),
    0 2px 6px rgba(0,0,0,.15)}
  .twk-chip>span{position:absolute;top:0;bottom:0;right:0;width:34%;
    display:flex;flex-direction:column;box-shadow:-1px 0 0 rgba(0,0,0,.1)}
  .twk-chip>span>i{flex:1;box-shadow:0 -1px 0 rgba(0,0,0,.1)}
  .twk-chip>span>i:first-child{box-shadow:none}
  .twk-chip svg{position:absolute;top:6px;left:6px;width:13px;height:13px;
    filter:drop-shadow(0 1px 1px rgba(0,0,0,.3))}
`;

// ── useTweaks ───────────────────────────────────────────────────────────────
// Single source of truth for tweak values. setTweak persists via the host
// (__edit_mode_set_keys → host rewrites the EDITMODE block on disk).
function useTweaks(defaults) {
  const [values, setValues] = React.useState(defaults);
  // Accepts either setTweak('key', value) or setTweak({ key: value, ... }) so a
  // useState-style call doesn't write a "[object Object]" key into the persisted
  // JSON block.
  const setTweak = React.useCallback((keyOrEdits, val) => {
    const edits = typeof keyOrEdits === 'object' && keyOrEdits !== null ? keyOrEdits : {
      [keyOrEdits]: val
    };
    setValues(prev => ({
      ...prev,
      ...edits
    }));
    window.parent.postMessage({
      type: '__edit_mode_set_keys',
      edits
    }, '*');
    // Same-window signal so in-page listeners (deck-stage rail thumbnails)
    // can react — the parent message only reaches the host, not peers.
    window.dispatchEvent(new CustomEvent('tweakchange', {
      detail: edits
    }));
  }, []);
  return [values, setTweak];
}

// ── TweaksPanel ─────────────────────────────────────────────────────────────
// Floating shell. Registers the protocol listener BEFORE announcing
// availability — if the announce ran first, the host's activate could land
// before our handler exists and the toolbar toggle would silently no-op.
// The close button posts __edit_mode_dismissed so the host's toolbar toggle
// flips off in lockstep; the host echoes __deactivate_edit_mode back which
// is what actually hides the panel.
function TweaksPanel({
  title = 'Tweaks',
  children
}) {
  const [open, setOpen] = React.useState(false);
  const dragRef = React.useRef(null);
  const offsetRef = React.useRef({
    x: 16,
    y: 16
  });
  const PAD = 16;
  const clampToViewport = React.useCallback(() => {
    const panel = dragRef.current;
    if (!panel) return;
    const w = panel.offsetWidth,
      h = panel.offsetHeight;
    const maxRight = Math.max(PAD, window.innerWidth - w - PAD);
    const maxBottom = Math.max(PAD, window.innerHeight - h - PAD);
    offsetRef.current = {
      x: Math.min(maxRight, Math.max(PAD, offsetRef.current.x)),
      y: Math.min(maxBottom, Math.max(PAD, offsetRef.current.y))
    };
    panel.style.right = offsetRef.current.x + 'px';
    panel.style.bottom = offsetRef.current.y + 'px';
  }, []);
  React.useEffect(() => {
    if (!open) return;
    clampToViewport();
    if (typeof ResizeObserver === 'undefined') {
      window.addEventListener('resize', clampToViewport);
      return () => window.removeEventListener('resize', clampToViewport);
    }
    const ro = new ResizeObserver(clampToViewport);
    ro.observe(document.documentElement);
    return () => ro.disconnect();
  }, [open, clampToViewport]);
  React.useEffect(() => {
    const onMsg = e => {
      const t = e?.data?.type;
      if (t === '__activate_edit_mode') setOpen(true);else if (t === '__deactivate_edit_mode') setOpen(false);
    };
    window.addEventListener('message', onMsg);
    window.parent.postMessage({
      type: '__edit_mode_available'
    }, '*');
    return () => window.removeEventListener('message', onMsg);
  }, []);
  const dismiss = () => {
    setOpen(false);
    window.parent.postMessage({
      type: '__edit_mode_dismissed'
    }, '*');
  };
  const onDragStart = e => {
    const panel = dragRef.current;
    if (!panel) return;
    const r = panel.getBoundingClientRect();
    const sx = e.clientX,
      sy = e.clientY;
    const startRight = window.innerWidth - r.right;
    const startBottom = window.innerHeight - r.bottom;
    const move = ev => {
      offsetRef.current = {
        x: startRight - (ev.clientX - sx),
        y: startBottom - (ev.clientY - sy)
      };
      clampToViewport();
    };
    const up = () => {
      window.removeEventListener('mousemove', move);
      window.removeEventListener('mouseup', up);
    };
    window.addEventListener('mousemove', move);
    window.addEventListener('mouseup', up);
  };

  // data-om-starter: inert presence marker — Claude Design's starter-usage
  // probe reads it. The closed panel renders nothing, so the marker rides
  // the <html> element as an attribute instead of a rendered node — zero
  // elements added, so page CSS (even structural selectors like
  // :nth-child) can never observe it. It records that the page WIRES a
  // tweaks panel, whether or not the panel is open. Keep this effect.
  React.useEffect(() => {
    document.documentElement.setAttribute('data-om-starter', 'tweaks-panel');
    return () => document.documentElement.removeAttribute('data-om-starter');
  }, []);
  if (!open) return null;
  return /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement("style", null, __TWEAKS_STYLE), /*#__PURE__*/React.createElement("div", {
    ref: dragRef,
    className: "twk-panel",
    "data-omelette-chrome": "",
    style: {
      right: offsetRef.current.x,
      bottom: offsetRef.current.y
    }
  }, /*#__PURE__*/React.createElement("div", {
    className: "twk-hd",
    onMouseDown: onDragStart
  }, /*#__PURE__*/React.createElement("b", null, title), /*#__PURE__*/React.createElement("button", {
    className: "twk-x",
    "aria-label": "Close tweaks",
    onMouseDown: e => e.stopPropagation(),
    onClick: dismiss
  }, "\u2715")), /*#__PURE__*/React.createElement("div", {
    className: "twk-body"
  }, children)));
}

// ── Layout helpers ──────────────────────────────────────────────────────────

function TweakSection({
  label,
  children
}) {
  return /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement("div", {
    className: "twk-sect"
  }, label), children);
}
function TweakRow({
  label,
  value,
  children,
  inline = false
}) {
  return /*#__PURE__*/React.createElement("div", {
    className: inline ? 'twk-row twk-row-h' : 'twk-row'
  }, /*#__PURE__*/React.createElement("div", {
    className: "twk-lbl"
  }, /*#__PURE__*/React.createElement("span", null, label), value != null && /*#__PURE__*/React.createElement("span", {
    className: "twk-val"
  }, value)), children);
}

// ── Controls ────────────────────────────────────────────────────────────────

function TweakSlider({
  label,
  value,
  min = 0,
  max = 100,
  step = 1,
  unit = '',
  onChange
}) {
  return /*#__PURE__*/React.createElement(TweakRow, {
    label: label,
    value: `${value}${unit}`
  }, /*#__PURE__*/React.createElement("input", {
    type: "range",
    className: "twk-slider",
    min: min,
    max: max,
    step: step,
    value: value,
    onChange: e => onChange(Number(e.target.value))
  }));
}
function TweakToggle({
  label,
  value,
  onChange
}) {
  return /*#__PURE__*/React.createElement("div", {
    className: "twk-row twk-row-h"
  }, /*#__PURE__*/React.createElement("div", {
    className: "twk-lbl"
  }, /*#__PURE__*/React.createElement("span", null, label)), /*#__PURE__*/React.createElement("button", {
    type: "button",
    className: "twk-toggle",
    "data-on": value ? '1' : '0',
    role: "switch",
    "aria-checked": !!value,
    onClick: () => onChange(!value)
  }, /*#__PURE__*/React.createElement("i", null)));
}
function TweakRadio({
  label,
  value,
  options,
  onChange
}) {
  const trackRef = React.useRef(null);
  const [dragging, setDragging] = React.useState(false);
  // The active value is read by pointer-move handlers attached for the lifetime
  // of a drag — ref it so a stale closure doesn't fire onChange for every move.
  const valueRef = React.useRef(value);
  valueRef.current = value;

  // Segments wrap mid-word once per-segment width runs out. The track is
  // ~248px (280 panel − 28 body pad − 4 seg pad), each button loses 12px
  // to its own padding, and 11.5px system-ui averages ~6.3px/char — so 2
  // options fit ~16 chars each, 3 fit ~10. Past that (or >3 options), fall
  // back to a dropdown rather than wrap.
  const labelLen = o => String(typeof o === 'object' ? o.label : o).length;
  const maxLen = options.reduce((m, o) => Math.max(m, labelLen(o)), 0);
  const fitsAsSegments = maxLen <= ({
    2: 16,
    3: 10
  }[options.length] ?? 0);
  if (!fitsAsSegments) {
    // <select> emits strings — map back to the original option value so the
    // fallback stays type-preserving (numbers, booleans) like the segment path.
    const resolve = s => {
      const m = options.find(o => String(typeof o === 'object' ? o.value : o) === s);
      return m === undefined ? s : typeof m === 'object' ? m.value : m;
    };
    return /*#__PURE__*/React.createElement(TweakSelect, {
      label: label,
      value: value,
      options: options,
      onChange: s => onChange(resolve(s))
    });
  }
  const opts = options.map(o => typeof o === 'object' ? o : {
    value: o,
    label: o
  });
  const idx = Math.max(0, opts.findIndex(o => o.value === value));
  const n = opts.length;
  const segAt = clientX => {
    const r = trackRef.current.getBoundingClientRect();
    const inner = r.width - 4;
    const i = Math.floor((clientX - r.left - 2) / inner * n);
    return opts[Math.max(0, Math.min(n - 1, i))].value;
  };
  const onPointerDown = e => {
    setDragging(true);
    const v0 = segAt(e.clientX);
    if (v0 !== valueRef.current) onChange(v0);
    const move = ev => {
      if (!trackRef.current) return;
      const v = segAt(ev.clientX);
      if (v !== valueRef.current) onChange(v);
    };
    const up = () => {
      setDragging(false);
      window.removeEventListener('pointermove', move);
      window.removeEventListener('pointerup', up);
    };
    window.addEventListener('pointermove', move);
    window.addEventListener('pointerup', up);
  };
  return /*#__PURE__*/React.createElement(TweakRow, {
    label: label
  }, /*#__PURE__*/React.createElement("div", {
    ref: trackRef,
    role: "radiogroup",
    onPointerDown: onPointerDown,
    className: dragging ? 'twk-seg dragging' : 'twk-seg'
  }, /*#__PURE__*/React.createElement("div", {
    className: "twk-seg-thumb",
    style: {
      left: `calc(2px + ${idx} * (100% - 4px) / ${n})`,
      width: `calc((100% - 4px) / ${n})`
    }
  }), opts.map(o => /*#__PURE__*/React.createElement("button", {
    key: o.value,
    type: "button",
    role: "radio",
    "aria-checked": o.value === value
  }, o.label))));
}
function TweakSelect({
  label,
  value,
  options,
  onChange
}) {
  return /*#__PURE__*/React.createElement(TweakRow, {
    label: label
  }, /*#__PURE__*/React.createElement("select", {
    className: "twk-field",
    value: value,
    onChange: e => onChange(e.target.value)
  }, options.map(o => {
    const v = typeof o === 'object' ? o.value : o;
    const l = typeof o === 'object' ? o.label : o;
    return /*#__PURE__*/React.createElement("option", {
      key: v,
      value: v
    }, l);
  })));
}
function TweakText({
  label,
  value,
  placeholder,
  onChange
}) {
  return /*#__PURE__*/React.createElement(TweakRow, {
    label: label
  }, /*#__PURE__*/React.createElement("input", {
    className: "twk-field",
    type: "text",
    value: value,
    placeholder: placeholder,
    onChange: e => onChange(e.target.value)
  }));
}
function TweakNumber({
  label,
  value,
  min,
  max,
  step = 1,
  unit = '',
  onChange
}) {
  const clamp = n => {
    if (min != null && n < min) return min;
    if (max != null && n > max) return max;
    return n;
  };
  const startRef = React.useRef({
    x: 0,
    val: 0
  });
  const onScrubStart = e => {
    e.preventDefault();
    startRef.current = {
      x: e.clientX,
      val: value
    };
    const decimals = (String(step).split('.')[1] || '').length;
    const move = ev => {
      const dx = ev.clientX - startRef.current.x;
      const raw = startRef.current.val + dx * step;
      const snapped = Math.round(raw / step) * step;
      onChange(clamp(Number(snapped.toFixed(decimals))));
    };
    const up = () => {
      window.removeEventListener('pointermove', move);
      window.removeEventListener('pointerup', up);
    };
    window.addEventListener('pointermove', move);
    window.addEventListener('pointerup', up);
  };
  return /*#__PURE__*/React.createElement("div", {
    className: "twk-num"
  }, /*#__PURE__*/React.createElement("span", {
    className: "twk-num-lbl",
    onPointerDown: onScrubStart
  }, label), /*#__PURE__*/React.createElement("input", {
    type: "number",
    value: value,
    min: min,
    max: max,
    step: step,
    onChange: e => onChange(clamp(Number(e.target.value)))
  }), unit && /*#__PURE__*/React.createElement("span", {
    className: "twk-num-unit"
  }, unit));
}

// Relative-luminance contrast pick — checkmarks drawn over a swatch need to
// read on both #111 and #fafafa without per-option configuration. Hex input
// only (#rgb / #rrggbb); named or rgb()/hsl() colors fall through to "light".
function __twkIsLight(hex) {
  const h = String(hex).replace('#', '');
  const x = h.length === 3 ? h.replace(/./g, c => c + c) : h.padEnd(6, '0');
  const n = parseInt(x.slice(0, 6), 16);
  if (Number.isNaN(n)) return true;
  const r = n >> 16 & 255,
    g = n >> 8 & 255,
    b = n & 255;
  return r * 299 + g * 587 + b * 114 > 148000;
}
const __TwkCheck = ({
  light
}) => /*#__PURE__*/React.createElement("svg", {
  viewBox: "0 0 14 14",
  "aria-hidden": "true"
}, /*#__PURE__*/React.createElement("path", {
  d: "M3 7.2 5.8 10 11 4.2",
  fill: "none",
  strokeWidth: "2.2",
  strokeLinecap: "round",
  strokeLinejoin: "round",
  stroke: light ? 'rgba(0,0,0,.78)' : '#fff'
}));

// TweakColor — curated color/palette picker. Each option is either a single
// hex string or an array of 1-5 hex strings; the card adapts — a lone color
// renders solid, a palette renders colors[0] as the hero (left ~2/3) with the
// rest stacked in a sharp column on the right. onChange emits the
// option in the shape it was passed (string stays string, array stays array).
// Without options it falls back to the native color input for back-compat.
function TweakColor({
  label,
  value,
  options,
  onChange
}) {
  if (!options || !options.length) {
    return /*#__PURE__*/React.createElement("div", {
      className: "twk-row twk-row-h"
    }, /*#__PURE__*/React.createElement("div", {
      className: "twk-lbl"
    }, /*#__PURE__*/React.createElement("span", null, label)), /*#__PURE__*/React.createElement("input", {
      type: "color",
      className: "twk-swatch",
      value: value,
      onChange: e => onChange(e.target.value)
    }));
  }
  // Native <input type=color> emits lowercase hex per the HTML spec, so
  // compare case-insensitively. String() guards JSON.stringify(undefined),
  // which returns the primitive undefined (no .toLowerCase).
  const key = o => String(JSON.stringify(o)).toLowerCase();
  const cur = key(value);
  return /*#__PURE__*/React.createElement(TweakRow, {
    label: label
  }, /*#__PURE__*/React.createElement("div", {
    className: "twk-chips",
    role: "radiogroup"
  }, options.map((o, i) => {
    const colors = Array.isArray(o) ? o : [o];
    const [hero, ...rest] = colors;
    const sup = rest.slice(0, 4);
    const on = key(o) === cur;
    return /*#__PURE__*/React.createElement("button", {
      key: i,
      type: "button",
      className: "twk-chip",
      role: "radio",
      "aria-checked": on,
      "data-on": on ? '1' : '0',
      "aria-label": colors.join(', '),
      title: colors.join(' · '),
      style: {
        background: hero
      },
      onClick: () => onChange(o)
    }, sup.length > 0 && /*#__PURE__*/React.createElement("span", null, sup.map((c, j) => /*#__PURE__*/React.createElement("i", {
      key: j,
      style: {
        background: c
      }
    }))), on && /*#__PURE__*/React.createElement(__TwkCheck, {
      light: __twkIsLight(hero)
    }));
  })));
}
function TweakButton({
  label,
  onClick,
  secondary = false
}) {
  return /*#__PURE__*/React.createElement("button", {
    type: "button",
    className: secondary ? 'twk-btn secondary' : 'twk-btn',
    onClick: onClick
  }, label);
}
Object.assign(window, {
  useTweaks,
  TweaksPanel,
  TweakSection,
  TweakRow,
  TweakSlider,
  TweakToggle,
  TweakRadio,
  TweakSelect,
  TweakText,
  TweakNumber,
  TweakColor,
  TweakButton
});
})(); } catch (e) { __ds_ns.__errors.push({ path: "guidelines/tweaks-panel.jsx", error: String((e && e.message) || e) }); }

// ui_kits/deltalk-app/App.jsx
try { (() => {
// Deltalk app orchestrator — phone frame, tab nav, auth, chat overlay, match toast
const {
  TabBar
} = window.DesignSystem_a1d7f7;
const {
  IcHome,
  IcHeart,
  IcChat,
  IcUser,
  PhoneAuth,
  Discover,
  Chats,
  Chat,
  Profile
} = window;
function StatusBar() {
  return /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      alignItems: "center",
      justifyContent: "space-between",
      padding: "10px 24px 2px",
      fontSize: 13,
      fontWeight: 600,
      color: "var(--text-primary)"
    }
  }, /*#__PURE__*/React.createElement("span", null, "\u06F9:\u06F4\u06F1"), /*#__PURE__*/React.createElement("span", {
    style: {
      display: "flex",
      gap: 5,
      alignItems: "center"
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: 11
    }
  }, "\u2582\u2584\u2586"), /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: 11
    }
  }, "\uDBC1\uDE47"), /*#__PURE__*/React.createElement("span", null, "\u06F8\u06F2\u066A")));
}
function MatchToast({
  onClose
}) {
  React.useEffect(() => {
    const t = setTimeout(onClose, 1800);
    return () => clearTimeout(t);
  }, []);
  return /*#__PURE__*/React.createElement("div", {
    style: {
      position: "absolute",
      top: 70,
      left: 20,
      right: 20,
      zIndex: 20,
      background: "var(--gradient-accent)",
      borderRadius: 16,
      padding: "14px 18px",
      display: "flex",
      alignItems: "center",
      gap: 10,
      boxShadow: "var(--shadow-lg)",
      animation: "dtDrop 300ms cubic-bezier(0.16,1,0.3,1)"
    }
  }, /*#__PURE__*/React.createElement(IcHeart, {
    size: 22,
    style: {
      color: "#fff"
    }
  }), /*#__PURE__*/React.createElement("span", {
    style: {
      color: "#fff",
      fontWeight: 500,
      fontSize: 15
    }
  }, "\u06CC\u06A9 \u0645\u0686 \u062C\u062F\u06CC\u062F! \uD83C\uDF89"));
}
function App() {
  const [screen, setScreen] = React.useState("auth"); // auth | app
  const [tab, setTab] = React.useState("heart");
  const [chat, setChat] = React.useState(null);
  const [theme, setTheme] = React.useState("light");
  const [toast, setToast] = React.useState(false);
  const toggleTheme = () => setTheme(t => t === "light" ? "dark" : "light");
  let body;
  if (screen === "auth") body = /*#__PURE__*/React.createElement(PhoneAuth, {
    onNext: () => setScreen("app")
  });else if (chat) body = /*#__PURE__*/React.createElement(Chat, {
    contact: chat,
    onBack: () => setChat(null)
  });else if (tab === "heart") body = /*#__PURE__*/React.createElement(Discover, {
    onMatch: () => setToast(true)
  });else if (tab === "home") body = /*#__PURE__*/React.createElement(Discover, {
    onMatch: () => setToast(true)
  });else if (tab === "chat") body = /*#__PURE__*/React.createElement(Chats, {
    onOpen: setChat
  });else body = /*#__PURE__*/React.createElement(Profile, {
    theme: theme,
    onToggleTheme: toggleTheme
  });
  const showTabs = screen === "app" && !chat;
  return /*#__PURE__*/React.createElement("div", {
    className: theme === "dark" ? "theme-dark" : "theme-light",
    style: {
      width: 390,
      height: 844,
      background: "var(--bg)",
      borderRadius: 44,
      overflow: "hidden",
      position: "relative",
      boxShadow: "0 30px 80px rgba(16,17,20,0.28)",
      border: "10px solid #111",
      transition: "background 200ms ease",
      display: "flex",
      flexDirection: "column"
    }
  }, /*#__PURE__*/React.createElement(StatusBar, null), toast && /*#__PURE__*/React.createElement(MatchToast, {
    onClose: () => setToast(false)
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1,
      minHeight: 0
    }
  }, body), showTabs && /*#__PURE__*/React.createElement(TabBar, {
    active: tab,
    onChange: setTab,
    items: [{
      key: "home",
      label: "خانه",
      icon: /*#__PURE__*/React.createElement(IcHome, null)
    }, {
      key: "heart",
      label: "کشف",
      icon: /*#__PURE__*/React.createElement(IcHeart, null)
    }, {
      key: "chat",
      label: "گفتگوها",
      icon: /*#__PURE__*/React.createElement(IcChat, null)
    }, {
      key: "user",
      label: "پروفایل",
      icon: /*#__PURE__*/React.createElement(IcUser, null)
    }]
  }));
}
window.App = App;
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/deltalk-app/App.jsx", error: String((e && e.message) || e) }); }

// ui_kits/deltalk-app/Chat.jsx
try { (() => {
// Deltalk — single conversation screen
const {
  Input,
  Avatar
} = window.DesignSystem_a1d7f7;
const {
  IcChevron,
  IcSend
} = window;
function Chat({
  contact,
  onBack
}) {
  const [msgs, setMsgs] = React.useState(window.DT_MESSAGES);
  const [draft, setDraft] = React.useState("");
  const scroller = React.useRef(null);
  React.useEffect(() => {
    if (scroller.current) scroller.current.scrollTop = scroller.current.scrollHeight;
  }, [msgs]);
  const send = () => {
    if (!draft.trim()) return;
    setMsgs(m => [...m, {
      me: true,
      text: draft,
      time: "الان"
    }]);
    setDraft("");
  };
  const c = contact || window.DT_CHATS[0];
  return /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      flexDirection: "column",
      height: "100%",
      background: "var(--bg)"
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      alignItems: "center",
      gap: 10,
      padding: "12px var(--screen-padding)",
      borderBottom: "0.5px solid var(--border-subtle)"
    }
  }, /*#__PURE__*/React.createElement("button", {
    onClick: onBack,
    style: {
      border: "none",
      background: "transparent",
      cursor: "pointer",
      padding: 4,
      display: "flex"
    }
  }, /*#__PURE__*/React.createElement(IcChevron, {
    size: 24,
    style: {
      color: "var(--text-primary)",
      transform: "scaleX(-1)"
    }
  })), /*#__PURE__*/React.createElement(Avatar, {
    initials: c.initial,
    size: 40,
    online: c.online
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 15,
      fontWeight: 500,
      color: "var(--text-primary)"
    }
  }, c.name), /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 12,
      color: c.online ? "var(--brand-pink)" : "var(--text-hint)"
    }
  }, c.online ? "آنلاین" : "آفلاین"))), /*#__PURE__*/React.createElement("div", {
    ref: scroller,
    style: {
      flex: 1,
      overflowY: "auto",
      padding: "16px var(--screen-padding)",
      display: "flex",
      flexDirection: "column",
      gap: 10
    }
  }, msgs.map((m, i) => /*#__PURE__*/React.createElement("div", {
    key: i,
    style: {
      alignSelf: m.me ? "flex-start" : "flex-end",
      maxWidth: "78%"
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      padding: "10px 14px",
      fontSize: 14,
      lineHeight: 1.6,
      borderRadius: m.me ? "16px 16px 4px 16px" : "16px 16px 16px 4px",
      background: m.me ? "var(--cta-bg)" : "var(--surface-card)",
      color: m.me ? "var(--cta-text)" : "var(--text-primary)",
      border: m.me ? "none" : "0.5px solid var(--border-subtle)"
    }
  }, m.text), /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 10,
      color: "var(--text-hint)",
      marginTop: 3,
      textAlign: m.me ? "left" : "right"
    }
  }, m.time)))), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      alignItems: "center",
      gap: 8,
      padding: "10px var(--screen-padding) calc(10px + env(safe-area-inset-bottom))",
      borderTop: "0.5px solid var(--border-subtle)"
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1
    }
  }, /*#__PURE__*/React.createElement(Input, {
    placeholder: "\u067E\u06CC\u0627\u0645 \u0628\u0646\u0648\u06CC\u0633\u06CC\u062F...",
    value: draft,
    onChange: e => setDraft(e.target.value),
    onKeyDown: e => e.key === "Enter" && send()
  })), /*#__PURE__*/React.createElement("button", {
    onClick: send,
    style: {
      width: 48,
      height: 48,
      flex: "0 0 auto",
      borderRadius: 14,
      border: "none",
      background: "var(--gradient-accent)",
      display: "flex",
      alignItems: "center",
      justifyContent: "center",
      cursor: "pointer"
    }
  }, /*#__PURE__*/React.createElement(IcSend, {
    size: 20,
    style: {
      color: "#fff",
      transform: "scaleX(-1)"
    }
  }))));
}
window.Chat = Chat;
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/deltalk-app/Chat.jsx", error: String((e && e.message) || e) }); }

// ui_kits/deltalk-app/Chats.jsx
try { (() => {
// Deltalk — Chats / matches list screen
const {
  Avatar,
  Badge
} = window.DesignSystem_a1d7f7;
function Chats({
  onOpen
}) {
  const chats = window.DT_CHATS;
  const newMatches = chats.filter(c => c.isNew);
  return /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      flexDirection: "column",
      height: "100%",
      background: "var(--bg)",
      overflow: "hidden"
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      padding: "14px var(--screen-padding) 8px"
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 24,
      fontWeight: 700,
      color: "var(--text-primary)"
    }
  }, "\u06AF\u0641\u062A\u06AF\u0648\u0647\u0627")), /*#__PURE__*/React.createElement("div", {
    style: {
      padding: "8px 0 4px"
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 13,
      fontWeight: 500,
      color: "var(--text-secondary)",
      padding: "0 var(--screen-padding) 10px"
    }
  }, "\u0645\u0686\u200C\u0647\u0627\u06CC \u062A\u0627\u0632\u0647"), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      gap: 14,
      overflowX: "auto",
      padding: "0 var(--screen-padding)"
    }
  }, newMatches.map(c => /*#__PURE__*/React.createElement("div", {
    key: c.id,
    style: {
      textAlign: "center",
      flex: "0 0 auto",
      cursor: "pointer"
    },
    onClick: () => onOpen(c)
  }, /*#__PURE__*/React.createElement(Avatar, {
    initials: c.initial,
    size: 62,
    ring: true,
    online: c.online,
    style: {
      ["--dummy"]: 0
    }
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 12,
      color: "var(--text-primary)",
      marginTop: 6
    }
  }, c.name))))), /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1,
      overflowY: "auto",
      marginTop: 10
    }
  }, chats.map(c => /*#__PURE__*/React.createElement("div", {
    key: c.id,
    onClick: () => onOpen(c),
    style: {
      display: "flex",
      alignItems: "center",
      gap: 12,
      padding: "12px var(--screen-padding)",
      cursor: "pointer"
    }
  }, /*#__PURE__*/React.createElement(Avatar, {
    initials: c.initial,
    size: 52,
    online: c.online
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1,
      minWidth: 0,
      borderBottom: "0.5px solid var(--border-subtle)",
      paddingBottom: 12
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      justifyContent: "space-between",
      alignItems: "center"
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: 15,
      fontWeight: 500,
      color: "var(--text-primary)"
    }
  }, c.name), /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: 12,
      color: c.unread ? "var(--brand-pink)" : "var(--text-hint)"
    }
  }, c.time)), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      justifyContent: "space-between",
      alignItems: "center",
      marginTop: 4,
      gap: 8
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: 13,
      color: "var(--text-secondary)",
      overflow: "hidden",
      textOverflow: "ellipsis",
      whiteSpace: "nowrap"
    }
  }, c.last), c.unread > 0 && /*#__PURE__*/React.createElement(Badge, null, c.unread)))))));
}
window.Chats = Chats;
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/deltalk-app/Chats.jsx", error: String((e && e.message) || e) }); }

// ui_kits/deltalk-app/Discover.jsx
try { (() => {
// Deltalk — Discover / swipe screen
const {
  Badge
} = window.DesignSystem_a1d7f7;
const {
  IcBell,
  IcX,
  IcHeart,
  IcStar,
  IcMap
} = window;
function Discover({
  onMatch
}) {
  const profiles = window.DT_PROFILES;
  const [idx, setIdx] = React.useState(0);
  const [leaving, setLeaving] = React.useState(null); // "like" | "nope"
  const p = profiles[idx % profiles.length];
  const act = dir => {
    setLeaving(dir);
    setTimeout(() => {
      setLeaving(null);
      setIdx(i => i + 1);
      if (dir === "like") onMatch && onMatch();
    }, 260);
  };
  const transform = leaving === "like" ? "translateX(120%) rotate(12deg)" : leaving === "nope" ? "translateX(-120%) rotate(-12deg)" : "none";
  return /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      flexDirection: "column",
      height: "100%",
      background: "var(--bg)"
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      alignItems: "center",
      justifyContent: "space-between",
      padding: "14px var(--screen-padding)"
    }
  }, /*#__PURE__*/React.createElement("img", {
    src: "../../assets/logo.svg",
    width: "30",
    height: "30",
    alt: ""
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 20,
      fontWeight: 500,
      color: "var(--text-primary)"
    }
  }, "\u06A9\u0634\u0641"), /*#__PURE__*/React.createElement("div", {
    style: {
      position: "relative"
    }
  }, /*#__PURE__*/React.createElement(IcBell, {
    size: 22,
    style: {
      color: "var(--text-secondary)"
    }
  }), /*#__PURE__*/React.createElement("span", {
    style: {
      position: "absolute",
      top: -2,
      insetInlineEnd: -2
    }
  }, /*#__PURE__*/React.createElement(Badge, {
    dot: true
  })))), /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1,
      padding: "4px var(--screen-padding) 0",
      position: "relative"
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      position: "absolute",
      inset: "4px 28px 0",
      background: "var(--surface-card)",
      borderRadius: "var(--radius-card)",
      border: "0.5px solid var(--border-subtle)",
      transform: "scale(0.95) translateY(10px)"
    }
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      position: "relative",
      height: "100%",
      borderRadius: "var(--radius-card)",
      overflow: "hidden",
      boxShadow: "var(--shadow-lg)",
      transition: "transform 260ms var(--ease-out)",
      transform
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      position: "absolute",
      inset: 0,
      background: p.grad,
      display: "flex",
      alignItems: "center",
      justifyContent: "center"
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: 120,
      fontWeight: 900,
      color: "rgba(255,255,255,0.9)"
    }
  }, p.initial)), /*#__PURE__*/React.createElement("div", {
    style: {
      position: "absolute",
      left: 0,
      right: 0,
      bottom: 0,
      padding: 20,
      background: "linear-gradient(to top,rgba(0,0,0,0.72),transparent)"
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      alignItems: "baseline",
      gap: 8
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: 24,
      fontWeight: 700,
      color: "#fff"
    }
  }, p.name), /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: 20,
      fontWeight: 400,
      color: "rgba(255,255,255,0.85)"
    }
  }, p.age)), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      alignItems: "center",
      gap: 6,
      margin: "6px 0 10px",
      color: "rgba(255,255,255,0.9)",
      fontSize: 13
    }
  }, /*#__PURE__*/React.createElement(IcMap, {
    size: 15
  }), /*#__PURE__*/React.createElement("span", null, p.city, " \xB7 ", p.dist)), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      gap: 8,
      flexWrap: "wrap"
    }
  }, p.tags.map(t => /*#__PURE__*/React.createElement("span", {
    key: t,
    style: {
      fontSize: 12,
      color: "#fff",
      padding: "4px 12px",
      borderRadius: 999,
      background: "rgba(255,255,255,0.18)",
      backdropFilter: "blur(4px)"
    }
  }, t)))))), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      alignItems: "center",
      justifyContent: "center",
      gap: 20,
      padding: "18px 0 22px"
    }
  }, /*#__PURE__*/React.createElement("button", {
    onClick: () => act("nope"),
    style: btn("var(--bg)", "var(--border-subtle)", 60)
  }, /*#__PURE__*/React.createElement(IcX, {
    size: 26,
    style: {
      color: "var(--text-secondary)"
    }
  })), /*#__PURE__*/React.createElement("button", {
    onClick: () => act("like"),
    style: btn("var(--gradient-accent)", "transparent", 68)
  }, /*#__PURE__*/React.createElement(IcHeart, {
    size: 30,
    style: {
      color: "#fff"
    }
  })), /*#__PURE__*/React.createElement("button", {
    onClick: () => act("nope"),
    style: btn("var(--bg)", "var(--border-subtle)", 60)
  }, /*#__PURE__*/React.createElement(IcStar, {
    size: 24,
    style: {
      color: "var(--brand-gold)"
    }
  }))));
}
function btn(bg, border, size) {
  return {
    width: size,
    height: size,
    borderRadius: "50%",
    background: bg,
    border: `0.5px solid ${border}`,
    display: "flex",
    alignItems: "center",
    justifyContent: "center",
    cursor: "pointer",
    boxShadow: "var(--shadow-md)"
  };
}
window.Discover = Discover;
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/deltalk-app/Discover.jsx", error: String((e && e.message) || e) }); }

// ui_kits/deltalk-app/PhoneAuth.jsx
try { (() => {
// Deltalk — phone auth / onboarding screen
const {
  Input,
  Button
} = window.DesignSystem_a1d7f7;
const {
  IcPhone,
  IcArrowR
} = window;
function PhoneAuth({
  onNext
}) {
  const [phone, setPhone] = React.useState("");
  return /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      flexDirection: "column",
      height: "100%",
      background: "var(--bg)",
      padding: "0 var(--screen-padding)"
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1,
      display: "flex",
      flexDirection: "column",
      alignItems: "center",
      justifyContent: "center",
      gap: 20
    }
  }, /*#__PURE__*/React.createElement("img", {
    src: "../../assets/logo-vertical-light.svg",
    alt: "Deltalk",
    style: {
      height: 150,
      width: "auto"
    }
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      textAlign: "center"
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 24,
      fontWeight: 700,
      color: "var(--text-primary)"
    }
  }, "\u0628\u0647 \u062F\u0644\u062A\u0627\u06A9 \u062E\u0648\u0634 \u0622\u0645\u062F\u06CC\u062F"), /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 15,
      color: "var(--text-secondary)",
      lineHeight: 1.7,
      marginTop: 6
    }
  }, "\u062C\u0627\u06CC\u06CC \u0628\u0631\u0627\u06CC \u062F\u0644\u200C\u0647\u0627\u061B \u0628\u0627 \u0622\u062F\u0645\u200C\u0647\u0627\u06CC \u062A\u0627\u0632\u0647 \u0622\u0634\u0646\u0627 \u0634\u0648\u06CC\u062F."))), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      flexDirection: "column",
      gap: "var(--input-gap)",
      paddingBottom: 28
    }
  }, /*#__PURE__*/React.createElement(Input, {
    label: "\u0634\u0645\u0627\u0631\u0647 \u0645\u0648\u0628\u0627\u06CC\u0644",
    placeholder: "\u06F0\u06F9\u06F1\u06F2 \u06F3\u06F4\u06F5 \u06F6\u06F7\u06F8\u06F9",
    value: phone,
    onChange: e => setPhone(e.target.value),
    leadingIcon: /*#__PURE__*/React.createElement(IcPhone, {
      size: 20,
      style: {
        color: "var(--text-hint)"
      }
    })
  }), /*#__PURE__*/React.createElement(Button, {
    variant: "primary",
    onClick: onNext,
    trailingIcon: /*#__PURE__*/React.createElement(IcArrowR, {
      size: 20
    })
  }, "\u062F\u0631\u06CC\u0627\u0641\u062A \u06A9\u062F \u062A\u0627\u06CC\u06CC\u062F"), /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 12,
      color: "var(--text-hint)",
      textAlign: "center",
      lineHeight: 1.7
    }
  }, "\u0628\u0627 \u0627\u062F\u0627\u0645\u0647\u060C ", /*#__PURE__*/React.createElement("a", {
    href: "#"
  }, "\u0642\u0648\u0627\u0646\u06CC\u0646"), " \u0648 ", /*#__PURE__*/React.createElement("a", {
    href: "#"
  }, "\u062D\u0631\u06CC\u0645 \u062E\u0635\u0648\u0635\u06CC"), " \u0631\u0627 \u0645\u06CC\u200C\u067E\u0630\u06CC\u0631\u06CC\u062F")));
}
window.PhoneAuth = PhoneAuth;
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/deltalk-app/PhoneAuth.jsx", error: String((e && e.message) || e) }); }

// ui_kits/deltalk-app/Profile.jsx
try { (() => {
// Deltalk — profile & settings screen
const {
  Button,
  Chip,
  Switch,
  Avatar
} = window.DesignSystem_a1d7f7;
const {
  IcSettings,
  IcSun,
  IcBell,
  IcShield,
  IcChevron,
  IcMap
} = window;
function Profile({
  theme,
  onToggleTheme
}) {
  const [notif, setNotif] = React.useState(true);
  const interests = ["سفر", "قهوه", "کتاب", "موسیقی", "پیاده‌روی"];
  const [sel, setSel] = React.useState(["سفر", "قهوه", "کتاب"]);
  const toggle = t => setSel(s => s.includes(t) ? s.filter(x => x !== t) : [...s, t]);
  const Row = ({
    icon,
    label,
    right
  }) => /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      alignItems: "center",
      gap: 12,
      padding: "14px 0",
      borderBottom: "0.5px solid var(--border-subtle)"
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      color: "var(--text-secondary)",
      display: "flex"
    }
  }, icon), /*#__PURE__*/React.createElement("span", {
    style: {
      flex: 1,
      fontSize: 15,
      color: "var(--text-primary)"
    }
  }, label), right);
  return /*#__PURE__*/React.createElement("div", {
    style: {
      height: "100%",
      overflowY: "auto",
      background: "var(--bg)"
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      padding: "20px var(--screen-padding) 0",
      display: "flex",
      flexDirection: "column",
      alignItems: "center",
      gap: 10
    }
  }, /*#__PURE__*/React.createElement(Avatar, {
    initials: "\u06A9",
    size: 92,
    ring: true
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      textAlign: "center"
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 20,
      fontWeight: 700,
      color: "var(--text-primary)"
    }
  }, "\u06A9\u0627\u0648\u0647\u060C \u06F2\u06F9"), /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 13,
      color: "var(--text-secondary)",
      marginTop: 2
    }
  }, "\u062A\u0647\u0631\u0627\u0646\u060C \u0627\u06CC\u0631\u0627\u0646")), /*#__PURE__*/React.createElement("div", {
    style: {
      width: "100%",
      marginTop: 4
    }
  }, /*#__PURE__*/React.createElement(Button, {
    variant: "secondary",
    leadingIcon: /*#__PURE__*/React.createElement(IcSettings, {
      size: 18
    })
  }, "\u0648\u06CC\u0631\u0627\u06CC\u0634 \u067E\u0631\u0648\u0641\u0627\u06CC\u0644"))), /*#__PURE__*/React.createElement("div", {
    style: {
      padding: "24px var(--screen-padding) 90px"
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 13,
      fontWeight: 500,
      color: "var(--text-secondary)",
      marginBottom: 12
    }
  }, "\u0639\u0644\u0627\u0642\u0647\u200C\u0645\u0646\u062F\u06CC\u200C\u0647\u0627"), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      flexWrap: "wrap",
      gap: 8,
      marginBottom: 24
    }
  }, interests.map(t => /*#__PURE__*/React.createElement(Chip, {
    key: t,
    selected: sel.includes(t),
    onClick: () => toggle(t)
  }, t))), /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 13,
      fontWeight: 500,
      color: "var(--text-secondary)",
      marginBottom: 4
    }
  }, "\u062A\u0646\u0638\u06CC\u0645\u0627\u062A"), /*#__PURE__*/React.createElement(Row, {
    icon: /*#__PURE__*/React.createElement(IcSun, {
      size: 22
    }),
    label: "\u062D\u0627\u0644\u062A \u062A\u06CC\u0631\u0647",
    right: /*#__PURE__*/React.createElement(Switch, {
      checked: theme === "dark",
      onChange: onToggleTheme
    })
  }), /*#__PURE__*/React.createElement(Row, {
    icon: /*#__PURE__*/React.createElement(IcBell, {
      size: 22
    }),
    label: "\u0627\u0639\u0644\u0627\u0646\u200C\u0647\u0627",
    right: /*#__PURE__*/React.createElement(Switch, {
      checked: notif,
      onChange: setNotif
    })
  }), /*#__PURE__*/React.createElement(Row, {
    icon: /*#__PURE__*/React.createElement(IcShield, {
      size: 22
    }),
    label: "\u062D\u0631\u06CC\u0645 \u062E\u0635\u0648\u0635\u06CC \u0648 \u0627\u0645\u0646\u06CC\u062A",
    right: /*#__PURE__*/React.createElement(IcChevron, {
      size: 20,
      style: {
        color: "var(--text-hint)"
      }
    })
  }), /*#__PURE__*/React.createElement(Row, {
    icon: /*#__PURE__*/React.createElement(IcMap, {
      size: 22
    }),
    label: "\u0645\u0648\u0642\u0639\u06CC\u062A \u0645\u06A9\u0627\u0646\u06CC",
    right: /*#__PURE__*/React.createElement("span", {
      style: {
        fontSize: 13,
        color: "var(--text-hint)"
      }
    }, "\u062A\u0647\u0631\u0627\u0646")
  })));
}
window.Profile = Profile;
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/deltalk-app/Profile.jsx", error: String((e && e.message) || e) }); }

// ui_kits/deltalk-app/data.js
try { (() => {
// Fake Deltalk profile + conversation data (Persian).
window.DT_PROFILES = [{
  id: 1,
  name: "نیلوفر",
  age: 27,
  city: "تهران",
  dist: "۳ کیلومتر",
  bio: "عاشق سفر، قهوهٔ صبحگاهی و پیاده‌روی‌های طولانی.",
  tags: ["سفر", "قهوه", "کتاب"],
  grad: "linear-gradient(160deg,#FFB565,#F24C9A)",
  initial: "ن"
}, {
  id: 2,
  name: "آرش",
  age: 31,
  city: "اصفهان",
  dist: "۸ کیلومتر",
  bio: "معمار، دوستدار موسیقی زنده و آشپزی آخر هفته.",
  tags: ["موسیقی", "آشپزی", "معماری"],
  grad: "linear-gradient(160deg,#A780FE,#5852E4)",
  initial: "آ"
}, {
  id: 3,
  name: "سارا",
  age: 24,
  city: "شیراز",
  dist: "۱۲ کیلومتر",
  bio: "دانشجوی هنر، نقاشی با آبرنگ و گربه‌بازی.",
  tags: ["هنر", "گربه", "فیلم"],
  grad: "linear-gradient(160deg,#F24C9A,#BB48F8)",
  initial: "س"
}];
window.DT_CHATS = [{
  id: 1,
  name: "نیلوفر",
  initial: "ن",
  grad: "linear-gradient(160deg,#FFB565,#F24C9A)",
  last: "سلام! خوشحالم که آشنا شدیم 🌸",
  time: "۱۰:۲۴",
  unread: 2,
  online: true,
  isNew: true
}, {
  id: 2,
  name: "آرش",
  initial: "آ",
  grad: "linear-gradient(160deg,#A780FE,#5852E4)",
  last: "آخر هفته برنامه‌ای داری؟",
  time: "دیروز",
  unread: 0,
  online: false,
  isNew: false
}, {
  id: 3,
  name: "سارا",
  initial: "س",
  grad: "linear-gradient(160deg,#F24C9A,#BB48F8)",
  last: "این آهنگو حتماً گوش بده",
  time: "دیروز",
  unread: 0,
  online: true,
  isNew: true
}, {
  id: 4,
  name: "مریم",
  initial: "م",
  grad: "linear-gradient(160deg,#5852E4,#261D82)",
  last: "ممنون بابت پیشنهادت 🙏",
  time: "۲ روز پیش",
  unread: 0,
  online: false,
  isNew: false
}];
window.DT_MESSAGES = [{
  me: false,
  text: "سلام! پروفایلت خیلی جالب بود 😊",
  time: "۱۰:۱۰"
}, {
  me: true,
  text: "سلام نیلوفر، مرسی! تو هم اهل سفری؟",
  time: "۱۰:۱۲"
}, {
  me: false,
  text: "خیلی زیاد! آخرین سفرم شمال بود.",
  time: "۱۰:۱۵"
}, {
  me: false,
  text: "تو معمولاً کجا میری؟",
  time: "۱۰:۱۵"
}, {
  me: true,
  text: "بیشتر کویر و کوهستان. آرامشش بی‌نظیره.",
  time: "۱۰:۲۰"
}, {
  me: false,
  text: "سلام! خوشحالم که آشنا شدیم 🌸",
  time: "۱۰:۲۴"
}];
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/deltalk-app/data.js", error: String((e && e.message) || e) }); }

// ui_kits/deltalk-app/icons.jsx
try { (() => {
// Shared Lucide-style outline icons (stroke 2) for the Deltalk UI kit.
// Built without JSX so the icon table parses cleanly.
const _svg = parts => props => {
  const s = props && (props.size || props.width) || 22;
  return React.createElement("svg", {
    viewBox: "0 0 24 24",
    fill: "none",
    stroke: props && props.stroke || "currentColor",
    strokeWidth: 2,
    strokeLinecap: "round",
    strokeLinejoin: "round",
    width: s,
    height: s,
    style: props && props.style
  }, parts.map((p, i) => React.createElement(p[0], Object.assign({
    key: i
  }, p[1]))));
};
const P = d => ["path", {
  d
}];
const IcHome = _svg([P("m3 9 9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"), ["polyline", {
  points: "9 22 9 12 15 12 15 22"
}]]);
const IcHeart = _svg([P("M19 14c1.49-1.46 3-3.21 3-5.5A5.5 5.5 0 0 0 16.5 3c-1.76 0-3 .5-4.5 2-1.5-1.5-2.74-2-4.5-2A5.5 5.5 0 0 0 2 8.5c0 2.29 1.51 4.04 3 5.5l7 7Z")]);
const IcChat = _svg([P("M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z")]);
const IcUser = _svg([["circle", {
  cx: 12,
  cy: 8,
  r: 5
}], P("M20 21a8 8 0 0 0-16 0")]);
const IcX = _svg([P("M18 6 6 18"), P("m6 6 12 12")]);
const IcStar = _svg([["polygon", {
  points: "12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2"
}]]);
const IcSend = _svg([P("m22 2-7 20-4-9-9-4Z"), P("M22 2 11 13")]);
const IcArrow = _svg([P("M5 12h14"), P("m12 5 7 7-7 7")]);
const IcArrowR = _svg([P("M19 12H5"), P("m12 19-7-7 7-7")]);
const IcPhone = _svg([P("M22 16.92v3a2 2 0 0 1-2.18 2 19.79 19.79 0 0 1-8.63-3.07 19.5 19.5 0 0 1-6-6 19.79 19.79 0 0 1-3.07-8.67A2 2 0 0 1 4.11 2h3a2 2 0 0 1 2 1.72c.13.96.36 1.9.7 2.81a2 2 0 0 1-.45 2.11L8.09 9.91a16 16 0 0 0 6 6l1.27-1.27a2 2 0 0 1 2.11-.45c.9.34 1.85.57 2.81.7A2 2 0 0 1 22 16.92z")]);
const IcSettings = _svg([["circle", {
  cx: 12,
  cy: 12,
  r: 3
}], P("M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 1 1-2.83 2.83l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 0 1-4 0v-.09A1.65 1.65 0 0 0 9 19.4a1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 1 1-2.83-2.83l.06-.06a1.65 1.65 0 0 0 .33-1.82 1.65 1.65 0 0 0-1.51-1H3a2 2 0 0 1 0-4h.09A1.65 1.65 0 0 0 4.6 9a1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 1 1 2.83-2.83l.06.06a1.65 1.65 0 0 0 1.82.33H9a1.65 1.65 0 0 0 1-1.51V3a2 2 0 0 1 4 0v.09a1.65 1.65 0 0 0 1 1.51 1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 1 1 2.83 2.83l-.06.06a1.65 1.65 0 0 0-.33 1.82V9a1.65 1.65 0 0 0 1.51 1H21a2 2 0 0 1 0 4h-.09a1.65 1.65 0 0 0-1.51 1z")]);
const IcMap = _svg([P("M20 10c0 6-8 12-8 12s-8-6-8-12a8 8 0 0 1 16 0Z"), ["circle", {
  cx: 12,
  cy: 10,
  r: 3
}]]);
const IcSun = _svg([["circle", {
  cx: 12,
  cy: 12,
  r: 4
}], P("M12 2v2M12 20v2M4.93 4.93l1.41 1.41M17.66 17.66l1.41 1.41M2 12h2M20 12h2M6.34 17.66l-1.41 1.41M19.07 4.93l-1.41 1.41")]);
const IcChevron = _svg([P("m15 18-6-6 6-6")]);
const IcBell = _svg([P("M6 8a6 6 0 0 1 12 0c0 7 3 9 3 9H3s3-2 3-9"), P("M10.3 21a1.94 1.94 0 0 0 3.4 0")]);
const IcShield = _svg([P("M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z")]);
Object.assign(window, {
  IcHome,
  IcHeart,
  IcChat,
  IcUser,
  IcX,
  IcStar,
  IcSend,
  IcArrow,
  IcArrowR,
  IcPhone,
  IcSettings,
  IcMap,
  IcSun,
  IcChevron,
  IcBell,
  IcShield
});
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/deltalk-app/icons.jsx", error: String((e && e.message) || e) }); }

__ds_ns.Avatar = __ds_scope.Avatar;

__ds_ns.Badge = __ds_scope.Badge;

__ds_ns.Button = __ds_scope.Button;

__ds_ns.Card = __ds_scope.Card;

__ds_ns.Chip = __ds_scope.Chip;

__ds_ns.GradientIcon = __ds_scope.GradientIcon;

__ds_ns.Input = __ds_scope.Input;

__ds_ns.Switch = __ds_scope.Switch;

__ds_ns.TabBar = __ds_scope.TabBar;

})();
