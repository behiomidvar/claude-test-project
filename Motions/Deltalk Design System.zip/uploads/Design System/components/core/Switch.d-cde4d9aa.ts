import * as React from "react";

/**
 * Deltalk toggle switch — on-state track is the pink→purple logo gradient, thumb is a white circle.
 * @startingPoint section="Core" subtitle="On/off toggle" viewport="200x60"
 */
export interface SwitchProps {
  checked?: boolean;
  onChange?: (next: boolean) => void;
  disabled?: boolean;
  style?: React.CSSProperties;
}
export declare function Switch(props: SwitchProps): JSX.Element;
