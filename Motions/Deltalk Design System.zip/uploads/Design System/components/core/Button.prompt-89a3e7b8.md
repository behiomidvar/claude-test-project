One-line: Deltalk's CTA button — solid charcoal (light) / near-white (dark), full-width by default, with a scale(0.97) press.

```jsx
<Button variant="primary" onClick={next}>ادامه</Button>
<Button variant="secondary" fullWidth={false}>رد کردن</Button>
<Button variant="ghost">بعداً</Button>
```

Variants: `primary` (default CTA), `secondary` (filled neutral card surface), `ghost` (outline only).
Sizes: `sm` 40px · `md` 52px (default) · `lg` 56px. Never fill with the logo gradient — that rule is reserved for chips, badges, and active nav.
