import React from "react";

/**
 * Deltalk text input. Card-surface fill, 12px radius, 48px tall, hairline border
 * that thickens to 1.5px pink on focus.
 */
export function Input({
  label = null,
  hint = null,
  error = null,
  leadingIcon = null,
  trailingIcon = null,
  value,
  onChange,
  placeholder,
  type = "text",
  disabled = false,
  style,
  ...rest
}) {
  const [focused, setFocused] = React.useState(false);
  const wrap = {
    display: "flex",
    alignItems: "center",
    gap: "var(--element-gap)",
    height: 48,
    padding: "0 14px",
    background: "var(--surface-card)",
    borderRadius: "var(--radius-input)",
    border: error
      ? "1.5px solid var(--brand-pink)"
      : focused
      ? "1.5px solid var(--brand-pink)"
      : "0.5px solid var(--border-subtle)",
    transition: "border-color var(--dur-theme) ease",
    opacity: disabled ? 0.5 : 1,
  };
  const input = {
    flex: 1,
    minWidth: 0,
    border: "none",
    outline: "none",
    background: "transparent",
    fontFamily: "var(--font-family)",
    fontSize: "var(--fs-body)",
    color: "var(--text-primary)",
    direction: "rtl",
    textAlign: "right",
  };
  return (
    <label style={{ display: "block", width: "100%", ...style }}>
      {label && (
        <span style={{ display: "block", marginBottom: 6, fontSize: "var(--fs-label)", fontWeight: "var(--fw-medium)", color: "var(--text-primary)" }}>{label}</span>
      )}
      <div style={wrap}>
        {leadingIcon}
        <input
          style={input}
          value={value}
          onChange={onChange}
          placeholder={placeholder}
          type={type}
          disabled={disabled}
          onFocus={() => setFocused(true)}
          onBlur={() => setFocused(false)}
          {...rest}
        />
        {trailingIcon}
      </div>
      {(hint || error) && (
        <span style={{ display: "block", marginTop: 6, fontSize: "var(--fs-caption)", color: error ? "var(--brand-pink)" : "var(--text-secondary)" }}>{error || hint}</span>
      )}
    </label>
  );
}
