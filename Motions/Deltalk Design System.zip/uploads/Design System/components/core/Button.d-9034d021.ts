import * as React from "react";

/**
 * Deltalk primary action button — the single highest-contrast solid element on a screen.
 * Charcoal fill on light theme, inverted near-white on dark. Never uses the logo gradient.
 *
 * @startingPoint section="Core" subtitle="Primary / secondary / ghost CTA" viewport="360x120"
 */
export interface ButtonProps {
  /** Visual weight. primary = solid CTA, secondary = filled neutral, ghost = outline */
  variant?: "primary" | "secondary" | "ghost";
  size?: "sm" | "md" | "lg";
  /** Stretch to container width (default true — CTAs are full-width) */
  fullWidth?: boolean;
  disabled?: boolean;
  leadingIcon?: React.ReactNode;
  trailingIcon?: React.ReactNode;
  onClick?: (e: React.MouseEvent) => void;
  children?: React.ReactNode;
  style?: React.CSSProperties;
}
export declare function Button(props: ButtonProps): JSX.Element;
