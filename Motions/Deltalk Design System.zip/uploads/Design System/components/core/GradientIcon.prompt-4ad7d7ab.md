One-line: Recolors a Lucide SVG's stroke with the pink→purple logo gradient for active/branded states only.

```jsx
<GradientIcon icon={<HeartIcon strokeWidth={2} />} size={22} />
```

Only for active tab icons, branded accents, and illustrations — never for default (inactive) icons, which stay `--text-secondary`/`--text-hint`.
