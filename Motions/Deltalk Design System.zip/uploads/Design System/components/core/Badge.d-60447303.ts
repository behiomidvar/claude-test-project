import * as React from "react";

/**
 * Notification badge / count pill — filled with the logo gradient. Also does online-dot mode.
 */
export interface BadgeProps {
  /** Render a bare indicator dot instead of a count pill */
  dot?: boolean;
  children?: React.ReactNode;
  style?: React.CSSProperties;
}
export declare function Badge(props: BadgeProps): JSX.Element;
