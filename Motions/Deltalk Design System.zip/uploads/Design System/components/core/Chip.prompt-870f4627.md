One-line: Pill-shaped filter/interest tag; selected = gold→pink gradient, white text, no border.

```jsx
<Chip selected>سفر</Chip>
<Chip>موسیقی</Chip>
```

The gradient selected state is one of the few sanctioned uses of logo color as a fill.
