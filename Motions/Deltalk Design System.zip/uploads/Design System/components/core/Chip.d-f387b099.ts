import * as React from "react";

/**
 * Deltalk chip / tag / filter pill. Selected state uses the gold→pink logo gradient.
 * @startingPoint section="Core" subtitle="Filter / interest pill" viewport="360x60"
 */
export interface ChipProps {
  /** Selected paints the gold→pink gradient with white text, no border */
  selected?: boolean;
  leadingIcon?: React.ReactNode;
  onClick?: (e: React.MouseEvent) => void;
  children?: React.ReactNode;
  style?: React.CSSProperties;
}
export declare function Chip(props: ChipProps): JSX.Element;
