import React from "react";

/**
 * Circular avatar. `ring` draws a gradient border (new-match indicator).
 * Pass `src` for a photo, or `children`/`initials` as a fallback.
 */
export function Avatar({ src, initials, size = 48, ring = false, online = false, style, ...rest }) {
  const inner = (
    <div
      style={{
        width: size,
        height: size,
        borderRadius: "50%",
        overflow: "hidden",
        background: "var(--surface-card)",
        border: "0.5px solid var(--border-subtle)",
        display: "flex",
        alignItems: "center",
        justifyContent: "center",
        fontFamily: "var(--font-family)",
        fontWeight: "var(--fw-medium)",
        fontSize: size * 0.38,
        color: "var(--text-secondary)",
      }}
    >
      {src ? <img src={src} alt="" style={{ width: "100%", height: "100%", objectFit: "cover" }} /> : initials}
    </div>
  );
  return (
    <div style={{ position: "relative", display: "inline-block", ...style }} {...rest}>
      {ring ? (
        <div style={{ padding: 2.5, borderRadius: "50%", background: "var(--gradient-accent)" }}>
          <div style={{ padding: 2, borderRadius: "50%", background: "var(--bg)" }}>{inner}</div>
        </div>
      ) : (
        inner
      )}
      {online && (
        <span style={{ position: "absolute", bottom: 1, insetInlineStart: 1, width: size * 0.24, height: size * 0.24, borderRadius: "50%", background: "var(--gradient-accent)", boxShadow: "0 0 0 2px var(--bg)" }} />
      )}
    </div>
  );
}
