One-line: Neutral surface container — the default block for content on any screen.

```jsx
<Card><p>محتوای کارت</p></Card>
<Card elevated padding="20px">…</Card>
```

Fill and border come from theme tokens, so it flips automatically light↔dark. Use `elevated` sparingly.
