import React from "react";

/**
 * Paints a Lucide-style SVG icon's stroke with a Deltalk logo gradient.
 * Works with a raw <svg> element or an icon component that forwards a `stroke` prop.
 * Use only for active/branded states (per accent rules).
 */
export function GradientIcon({ icon, size = 22, from = "#F24C9A", to = "#BB48F8", style }) {
  const gid = "dtg-" + React.useId().replace(/:/g, "");
  if (!icon) return null;
  return (
    <span style={{ display: "inline-flex", lineHeight: 0, ...style }}>
      <svg width="0" height="0" style={{ position: "absolute" }} aria-hidden="true">
        <defs>
          <linearGradient id={gid} x1="0" y1="0" x2="1" y2="1">
            <stop offset="0" stopColor={from} />
            <stop offset="1" stopColor={to} />
          </linearGradient>
        </defs>
      </svg>
      {React.cloneElement(icon, { width: size, height: size, size, stroke: `url(#${gid})` })}
    </span>
  );
}
