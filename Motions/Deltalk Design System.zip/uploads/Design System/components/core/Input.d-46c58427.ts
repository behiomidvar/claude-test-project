import * as React from "react";

/**
 * Deltalk text field — card-surface fill, hairline border thickening to 1.5px pink on focus.
 * @startingPoint section="Core" subtitle="Text input with label + hint" viewport="360x110"
 */
export interface InputProps {
  label?: React.ReactNode;
  hint?: React.ReactNode;
  /** Error message — also paints the border pink */
  error?: React.ReactNode;
  leadingIcon?: React.ReactNode;
  trailingIcon?: React.ReactNode;
  value?: string;
  onChange?: (e: React.ChangeEvent<HTMLInputElement>) => void;
  placeholder?: string;
  type?: string;
  disabled?: boolean;
  style?: React.CSSProperties;
}
export declare function Input(props: InputProps): JSX.Element;
