import React from "react";

/**
 * Deltalk chip / tag. Unselected = card surface with hairline border and secondary text.
 * Selected = gold→pink 135° gradient with white text and no border (identical both themes).
 */
export function Chip({ selected = false, leadingIcon = null, onClick, children, style, ...rest }) {
  const base = {
    display: "inline-flex",
    alignItems: "center",
    gap: "6px",
    height: 34,
    padding: "0 14px",
    borderRadius: "var(--radius-chip)",
    fontFamily: "var(--font-family)",
    fontSize: "var(--fs-label)",
    fontWeight: "var(--fw-medium)",
    cursor: "pointer",
    userSelect: "none",
    transition: "background var(--dur-theme) ease, color var(--dur-theme) ease",
    whiteSpace: "nowrap",
  };
  const skin = selected
    ? { background: "var(--gradient-chip)", color: "#FFFFFF", border: "0.5px solid transparent" }
    : { background: "var(--surface-card)", color: "var(--text-secondary)", border: "0.5px solid var(--border-subtle)" };
  return (
    <button type="button" onClick={onClick} style={{ ...base, ...skin, ...style }} {...rest}>
      {leadingIcon}
      {children}
    </button>
  );
}
