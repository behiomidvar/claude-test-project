One-line: Round avatar; `ring` adds the gradient new-match border, `online` adds a gradient status dot.

```jsx
<Avatar src={photo} size={56} ring online />
<Avatar initials="ن" size={40} />
```
