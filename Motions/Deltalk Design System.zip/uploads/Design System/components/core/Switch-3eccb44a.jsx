import React from "react";

/**
 * Deltalk toggle switch. On-state track uses the pink→purple logo gradient with a white thumb.
 */
export function Switch({ checked = false, onChange, disabled = false, style, ...rest }) {
  const toggle = () => { if (!disabled && onChange) onChange(!checked); };
  return (
    <button
      type="button"
      role="switch"
      aria-checked={checked}
      disabled={disabled}
      onClick={toggle}
      style={{
        position: "relative",
        width: 48,
        height: 28,
        flex: "0 0 auto",
        borderRadius: 999,
        border: "none",
        padding: 0,
        cursor: disabled ? "not-allowed" : "pointer",
        opacity: disabled ? 0.5 : 1,
        background: checked ? "var(--gradient-accent)" : "var(--border-subtle)",
        transition: "background var(--dur-theme) ease",
        ...style,
      }}
      {...rest}
    >
      <span
        style={{
          position: "absolute",
          top: 3,
          left: checked ? 23 : 3,
          width: 22,
          height: 22,
          borderRadius: "50%",
          background: "#FFFFFF",
          boxShadow: "var(--shadow-sm)",
          transition: "left var(--dur-theme) var(--ease-out)",
        }}
      />
    </button>
  );
}
