import React from "react";

/**
 * Small notification badge / count pill. Filled with the logo gradient (accent-sanctioned).
 * Use `dot` for a bare indicator, or pass a count as children.
 */
export function Badge({ dot = false, children, style, ...rest }) {
  if (dot) {
    return (
      <span
        style={{ display: "inline-block", width: 10, height: 10, borderRadius: "50%", background: "var(--gradient-accent)", boxShadow: "0 0 0 2px var(--bg)", ...style }}
        {...rest}
      />
    );
  }
  return (
    <span
      style={{
        display: "inline-flex",
        alignItems: "center",
        justifyContent: "center",
        minWidth: 18,
        height: 18,
        padding: "0 5px",
        borderRadius: 999,
        background: "var(--gradient-accent)",
        color: "#FFFFFF",
        fontFamily: "var(--font-family)",
        fontSize: "11px",
        fontWeight: "var(--fw-bold)",
        lineHeight: 1,
        ...style,
      }}
      {...rest}
    >
      {children}
    </span>
  );
}
