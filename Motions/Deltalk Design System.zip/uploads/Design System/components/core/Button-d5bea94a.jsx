import React from "react";

/**
 * Deltalk primary action button. The highest-contrast solid element on a screen —
 * charcoal on light, near-white on dark. Never filled with the logo gradient.
 */
export function Button({
  variant = "primary",
  size = "md",
  fullWidth = true,
  disabled = false,
  leadingIcon = null,
  trailingIcon = null,
  onClick,
  children,
  style,
  ...rest
}) {
  const heights = { sm: 40, md: 52, lg: 56 };
  const pads = { sm: "0 16px", md: "0 20px", lg: "0 24px" };
  const base = {
    display: "inline-flex",
    alignItems: "center",
    justifyContent: "center",
    gap: "var(--element-gap)",
    height: heights[size],
    padding: pads[size],
    width: fullWidth ? "100%" : "auto",
    borderRadius: "var(--radius-button)",
    fontFamily: "var(--font-family)",
    fontSize: size === "sm" ? "var(--fs-label)" : "var(--fs-body)",
    fontWeight: "var(--fw-medium)",
    cursor: disabled ? "not-allowed" : "pointer",
    opacity: disabled ? 0.4 : 1,
    border: "0.5px solid transparent",
    transition: "transform var(--dur-press) var(--ease-out), background var(--dur-theme) ease, opacity var(--dur-theme) ease",
    userSelect: "none",
  };
  const variants = {
    primary: { background: "var(--cta-bg)", color: "var(--cta-text)", borderColor: "var(--cta-bg)", hoverBg: "var(--cta-hover)" },
    secondary: { background: "var(--surface-card)", color: "var(--text-primary)", borderColor: "var(--border-subtle)", hoverBg: "var(--bg-subtle)", hoverBorder: "var(--border-strong)" },
    ghost: { background: "transparent", color: "var(--text-primary)", borderColor: "var(--border-subtle)", hoverBg: "var(--bg-subtle)", hoverBorder: "var(--border-strong)" },
  };
  const { hoverBg, hoverBorder, ...vstyle } = variants[variant];
  const enter = (e) => { if (disabled) return; if (hoverBg) e.currentTarget.style.background = hoverBg; if (hoverBorder) e.currentTarget.style.borderColor = hoverBorder; };
  const leave = (e) => { e.currentTarget.style.transform = "scale(1)"; e.currentTarget.style.background = vstyle.background; e.currentTarget.style.borderColor = vstyle.borderColor; };
  const press = (e) => { if (!disabled) e.currentTarget.style.transform = "scale(0.97)"; };
  const release = (e) => { e.currentTarget.style.transform = "scale(1)"; };
  return (
    <button
      type="button"
      disabled={disabled}
      onClick={onClick}
      onPointerDown={press}
      onPointerUp={release}
      onPointerEnter={enter}
      onPointerLeave={leave}
      style={{ ...base, ...vstyle, ...style }}
      {...rest}
    >
      {leadingIcon}
      {children}
      {trailingIcon}
    </button>
  );
}
