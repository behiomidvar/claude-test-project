import * as React from "react";

/**
 * Deltalk surface card — card-surface fill, 20px radius, hairline border, 16px padding.
 * @startingPoint section="Core" subtitle="Surface container" viewport="360x160"
 */
export interface CardProps {
  padding?: string | number;
  /** Add a soft shadow instead of relying on the border alone */
  elevated?: boolean;
  onClick?: (e: React.MouseEvent) => void;
  children?: React.ReactNode;
  style?: React.CSSProperties;
}
export declare function Card(props: CardProps): JSX.Element;
