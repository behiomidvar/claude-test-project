import React from "react";

/**
 * Deltalk surface card. Very light gray (light) / dark charcoal (dark),
 * 20px radius, hairline border, 16px padding.
 */
export function Card({ padding = "var(--card-padding)", elevated = false, onClick, children, style, ...rest }) {
  return (
    <div
      onClick={onClick}
      style={{
        background: "var(--surface-card)",
        border: "0.5px solid var(--border-subtle)",
        borderRadius: "var(--radius-card)",
        padding,
        boxShadow: elevated ? "var(--shadow-md)" : "none",
        cursor: onClick ? "pointer" : "default",
        ...style,
      }}
      {...rest}
    >
      {children}
    </div>
  );
}
