One-line: Gradient count pill or online/notification dot.

```jsx
<Badge>۳</Badge>
<Badge dot />
```

One of the sanctioned gradient-as-fill uses. Keep it tiny.
