import * as React from "react";

/**
 * Circular avatar with an optional gradient ring (new match) and online dot.
 * @startingPoint section="Core" subtitle="Avatar with match ring" viewport="240x100"
 */
export interface AvatarProps {
  src?: string;
  /** Fallback initials when no src */
  initials?: React.ReactNode;
  size?: number;
  /** Gradient border ring — signals a new match */
  ring?: boolean;
  online?: boolean;
  style?: React.CSSProperties;
}
export declare function Avatar(props: AvatarProps): JSX.Element;
