One-line: Controlled on/off toggle; on-track uses the pink→purple gradient.

```jsx
const [on, setOn] = React.useState(true);
<Switch checked={on} onChange={setOn} />
```

Controlled only — always pass `checked` and `onChange`.
