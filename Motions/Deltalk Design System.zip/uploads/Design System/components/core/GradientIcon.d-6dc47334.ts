import * as React from "react";

/**
 * Paints a Lucide icon's stroke with a logo gradient — reserved for active/branded states.
 */
export interface GradientIconProps {
  /** A Lucide <svg> React element (e.g. from lucide-react or a raw SVG) */
  icon: React.ReactElement;
  size?: number;
  /** Gradient start / end (default pink→purple) */
  from?: string;
  to?: string;
  style?: React.CSSProperties;
}
export declare function GradientIcon(props: GradientIconProps): JSX.Element;
