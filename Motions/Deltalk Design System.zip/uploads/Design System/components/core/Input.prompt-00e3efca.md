One-line: RTL text field on card surface; border goes 1.5px pink on focus or error.

```jsx
<Input label="شماره موبایل" placeholder="۰۹۱۲ ..." hint="کد تایید برایتان پیامک می‌شود" />
```

Pass `leadingIcon`/`trailingIcon` (Lucide, 22px). `error` overrides `hint` and paints the border pink.
