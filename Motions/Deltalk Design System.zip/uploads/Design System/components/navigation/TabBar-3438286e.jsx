import React from "react";
import { GradientIcon } from "../core/GradientIcon.jsx";

/**
 * Deltalk bottom tab bar. Active icon painted with the logo gradient; inactive icons hint-gray.
 * items: [{ key, label, icon }] where icon is a Lucide <svg> element.
 */
export function TabBar({ items = [], active, onChange, style, ...rest }) {
  return (
    <nav
      style={{
        display: "flex",
        alignItems: "stretch",
        justifyContent: "space-around",
        background: "var(--bg)",
        borderTop: "0.5px solid var(--border-subtle)",
        padding: "8px 8px calc(8px + env(safe-area-inset-bottom))",
        ...style,
      }}
      {...rest}
    >
      {items.map((it) => {
        const isActive = it.key === active;
        return (
          <button
            key={it.key}
            type="button"
            onClick={() => onChange && onChange(it.key)}
            style={{
              flex: 1,
              display: "flex",
              flexDirection: "column",
              alignItems: "center",
              gap: 4,
              minHeight: 44,
              padding: "6px 4px",
              border: "none",
              background: "transparent",
              cursor: "pointer",
              fontFamily: "var(--font-family)",
            }}
          >
            {isActive ? (
              <GradientIcon icon={it.icon} size={24} />
            ) : (
              React.cloneElement(it.icon, { width: 24, height: 24, size: 24, stroke: "var(--text-hint)", style: { display: "block" } })
            )}
            <span style={{ fontSize: "11px", fontWeight: isActive ? "var(--fw-medium)" : "var(--fw-regular)", color: isActive ? "var(--text-primary)" : "var(--text-hint)" }}>{it.label}</span>
          </button>
        );
      })}
    </nav>
  );
}
