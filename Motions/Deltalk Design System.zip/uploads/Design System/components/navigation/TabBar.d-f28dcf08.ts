import * as React from "react";

export interface TabItem {
  key: string;
  label: React.ReactNode;
  /** A Lucide <svg> React element */
  icon: React.ReactElement;
}

/**
 * Deltalk bottom navigation. Active tab icon is gradient-filled; inactive icons are hint-gray.
 * @startingPoint section="Navigation" subtitle="Bottom tab bar" viewport="360x80"
 */
export interface TabBarProps {
  items: TabItem[];
  /** key of the active tab */
  active: string;
  onChange?: (key: string) => void;
  style?: React.CSSProperties;
}
export declare function TabBar(props: TabBarProps): JSX.Element;
