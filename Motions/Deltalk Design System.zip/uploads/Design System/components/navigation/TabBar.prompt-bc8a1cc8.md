One-line: Bottom tab bar; active icon gets the logo gradient, inactive icons stay hint-gray.

```jsx
<TabBar
  active="home"
  onChange={setTab}
  items={[
    { key: "home", label: "خانه", icon: <HomeSvg /> },
    { key: "chats", label: "گفتگوها", icon: <MessageSvg /> },
  ]}
/>
```

`icon` must be a raw Lucide `<svg>` element so its stroke can be recolored.
