---
name: deltalk-design
description: Use this skill to generate well-branded interfaces and assets for Deltalk (دلتاک), a Persian (Farsi, RTL) dating app, either for production or throwaway prototypes/mocks/etc. Contains essential design guidelines, colors, type, fonts, assets, and UI kit components for prototyping.
user-invocable: true
---

Read the README.md file within this skill, and explore the other available files.
If creating visual artifacts (slides, mocks, throwaway prototypes, etc), copy assets out and create static HTML files for the user to view. If working on production code, you can copy assets and read the rules here to become an expert in designing with this brand.
If the user invokes this skill without any other guidance, ask them what they want to build or design, ask some questions, and act as an expert designer who outputs HTML artifacts _or_ production code, depending on the need.

Key facts:
- Persian (Farsi), RTL, IranSans font (`assets/fonts/`, declared in `tokens/fonts.css`).
- Link `styles.css` to get all tokens; components live in `_ds_bundle.js` under `window.DesignSystem_a1d7f7`.
- Cool blue-gray neutral ramp (hue ≈ 218°). Light theme = #F8FAFC screens / #FFFFFF cards; dark = #121926 screens / #1D2432 cards. Never mix themes on one screen.
- Logo gradient colors (gold/pink/purple/indigo/navy) are ACCENT ONLY — never a CTA or background fill. Primary CTA is charcoal (light) / near-white (dark).
- Logo is `assets/logo.svg` — use verbatim, never redraw.
