// Deltalk — phone auth / onboarding screen
const { Input, Button } = window.DesignSystem_a1d7f7;
const { IcPhone, IcArrowR } = window;
function PhoneAuth({ onNext }) {
  const [phone, setPhone] = React.useState("");
  return (
    <div style={{ display: "flex", flexDirection: "column", height: "100%", background: "var(--bg)", padding: "0 var(--screen-padding)" }}>
      <div style={{ flex: 1, display: "flex", flexDirection: "column", alignItems: "center", justifyContent: "center", gap: 20 }}>
        <img src="../../assets/logo-vertical-light.svg" alt="Deltalk" style={{ height: 150, width: "auto" }} />
        <div style={{ textAlign: "center" }}>
          <div style={{ fontSize: 24, fontWeight: 700, color: "var(--text-primary)" }}>به دلتاک خوش آمدید</div>
          <div style={{ fontSize: 15, color: "var(--text-secondary)", lineHeight: 1.7, marginTop: 6 }}>جایی برای دل‌ها؛ با آدم‌های تازه آشنا شوید.</div>
        </div>
      </div>
      <div style={{ display: "flex", flexDirection: "column", gap: "var(--input-gap)", paddingBottom: 28 }}>
        <Input label="شماره موبایل" placeholder="۰۹۱۲ ۳۴۵ ۶۷۸۹" value={phone} onChange={(e) => setPhone(e.target.value)} leadingIcon={<IcPhone size={20} style={{ color: "var(--text-hint)" }} />} />
        <Button variant="primary" onClick={onNext} trailingIcon={<IcArrowR size={20} />}>دریافت کد تایید</Button>
        <div style={{ fontSize: 12, color: "var(--text-hint)", textAlign: "center", lineHeight: 1.7 }}>با ادامه، <a href="#">قوانین</a> و <a href="#">حریم خصوصی</a> را می‌پذیرید</div>
      </div>
    </div>
  );
}
window.PhoneAuth = PhoneAuth;
