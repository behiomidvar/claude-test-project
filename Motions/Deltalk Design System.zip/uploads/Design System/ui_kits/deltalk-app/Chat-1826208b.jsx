// Deltalk — single conversation screen
const { Input, Avatar } = window.DesignSystem_a1d7f7;
const { IcChevron, IcSend } = window;
function Chat({ contact, onBack }) {
  const [msgs, setMsgs] = React.useState(window.DT_MESSAGES);
  const [draft, setDraft] = React.useState("");
  const scroller = React.useRef(null);
  React.useEffect(() => { if (scroller.current) scroller.current.scrollTop = scroller.current.scrollHeight; }, [msgs]);
  const send = () => {
    if (!draft.trim()) return;
    setMsgs((m) => [...m, { me: true, text: draft, time: "الان" }]);
    setDraft("");
  };
  const c = contact || window.DT_CHATS[0];
  return (
    <div style={{ display: "flex", flexDirection: "column", height: "100%", background: "var(--bg)" }}>
      <div style={{ display: "flex", alignItems: "center", gap: 10, padding: "12px var(--screen-padding)", borderBottom: "0.5px solid var(--border-subtle)" }}>
        <button onClick={onBack} style={{ border: "none", background: "transparent", cursor: "pointer", padding: 4, display: "flex" }}><IcChevron size={24} style={{ color: "var(--text-primary)", transform: "scaleX(-1)" }} /></button>
        <Avatar initials={c.initial} size={40} online={c.online} />
        <div style={{ flex: 1 }}>
          <div style={{ fontSize: 15, fontWeight: 500, color: "var(--text-primary)" }}>{c.name}</div>
          <div style={{ fontSize: 12, color: c.online ? "var(--brand-pink)" : "var(--text-hint)" }}>{c.online ? "آنلاین" : "آفلاین"}</div>
        </div>
      </div>
      <div ref={scroller} style={{ flex: 1, overflowY: "auto", padding: "16px var(--screen-padding)", display: "flex", flexDirection: "column", gap: 10 }}>
        {msgs.map((m, i) => (
          <div key={i} style={{ alignSelf: m.me ? "flex-start" : "flex-end", maxWidth: "78%" }}>
            <div style={{
              padding: "10px 14px", fontSize: 14, lineHeight: 1.6,
              borderRadius: m.me ? "16px 16px 4px 16px" : "16px 16px 16px 4px",
              background: m.me ? "var(--cta-bg)" : "var(--surface-card)",
              color: m.me ? "var(--cta-text)" : "var(--text-primary)",
              border: m.me ? "none" : "0.5px solid var(--border-subtle)",
            }}>{m.text}</div>
            <div style={{ fontSize: 10, color: "var(--text-hint)", marginTop: 3, textAlign: m.me ? "left" : "right" }}>{m.time}</div>
          </div>
        ))}
      </div>
      <div style={{ display: "flex", alignItems: "center", gap: 8, padding: "10px var(--screen-padding) calc(10px + env(safe-area-inset-bottom))", borderTop: "0.5px solid var(--border-subtle)" }}>
        <div style={{ flex: 1 }}>
          <Input placeholder="پیام بنویسید..." value={draft} onChange={(e) => setDraft(e.target.value)} onKeyDown={(e) => e.key === "Enter" && send()} />
        </div>
        <button onClick={send} style={{ width: 48, height: 48, flex: "0 0 auto", borderRadius: 14, border: "none", background: "var(--gradient-accent)", display: "flex", alignItems: "center", justifyContent: "center", cursor: "pointer" }}>
          <IcSend size={20} style={{ color: "#fff", transform: "scaleX(-1)" }} />
        </button>
      </div>
    </div>
  );
}
window.Chat = Chat;
