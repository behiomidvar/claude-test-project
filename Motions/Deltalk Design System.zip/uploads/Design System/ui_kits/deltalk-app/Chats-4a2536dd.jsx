// Deltalk — Chats / matches list screen
const { Avatar, Badge } = window.DesignSystem_a1d7f7;
function Chats({ onOpen }) {
  const chats = window.DT_CHATS;
  const newMatches = chats.filter((c) => c.isNew);
  return (
    <div style={{ display: "flex", flexDirection: "column", height: "100%", background: "var(--bg)", overflow: "hidden" }}>
      <div style={{ padding: "14px var(--screen-padding) 8px" }}>
        <div style={{ fontSize: 24, fontWeight: 700, color: "var(--text-primary)" }}>گفتگوها</div>
      </div>
      <div style={{ padding: "8px 0 4px" }}>
        <div style={{ fontSize: 13, fontWeight: 500, color: "var(--text-secondary)", padding: "0 var(--screen-padding) 10px" }}>مچ‌های تازه</div>
        <div style={{ display: "flex", gap: 14, overflowX: "auto", padding: "0 var(--screen-padding)" }}>
          {newMatches.map((c) => (
            <div key={c.id} style={{ textAlign: "center", flex: "0 0 auto", cursor: "pointer" }} onClick={() => onOpen(c)}>
              <Avatar initials={c.initial} size={62} ring online={c.online} style={{ ["--dummy"]: 0 }} />
              <div style={{ fontSize: 12, color: "var(--text-primary)", marginTop: 6 }}>{c.name}</div>
            </div>
          ))}
        </div>
      </div>
      <div style={{ flex: 1, overflowY: "auto", marginTop: 10 }}>
        {chats.map((c) => (
          <div key={c.id} onClick={() => onOpen(c)} style={{ display: "flex", alignItems: "center", gap: 12, padding: "12px var(--screen-padding)", cursor: "pointer" }}>
            <Avatar initials={c.initial} size={52} online={c.online} />
            <div style={{ flex: 1, minWidth: 0, borderBottom: "0.5px solid var(--border-subtle)", paddingBottom: 12 }}>
              <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center" }}>
                <span style={{ fontSize: 15, fontWeight: 500, color: "var(--text-primary)" }}>{c.name}</span>
                <span style={{ fontSize: 12, color: c.unread ? "var(--brand-pink)" : "var(--text-hint)" }}>{c.time}</span>
              </div>
              <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginTop: 4, gap: 8 }}>
                <span style={{ fontSize: 13, color: "var(--text-secondary)", overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>{c.last}</span>
                {c.unread > 0 && <Badge>{c.unread}</Badge>}
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
window.Chats = Chats;
