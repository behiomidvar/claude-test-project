// Deltalk app orchestrator — phone frame, tab nav, auth, chat overlay, match toast
const { TabBar } = window.DesignSystem_a1d7f7;
const { IcHome, IcHeart, IcChat, IcUser, PhoneAuth, Discover, Chats, Chat, Profile } = window;
function StatusBar() {
  return (
    <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", padding: "10px 24px 2px", fontSize: 13, fontWeight: 600, color: "var(--text-primary)" }}>
      <span>۹:۴۱</span>
      <span style={{ display: "flex", gap: 5, alignItems: "center" }}>
        <span style={{ fontSize: 11 }}>▂▄▆</span><span style={{ fontSize: 11 }}>􀙇</span><span>۸۲٪</span>
      </span>
    </div>
  );
}
function MatchToast({ onClose }) {
  React.useEffect(() => { const t = setTimeout(onClose, 1800); return () => clearTimeout(t); }, []);
  return (
    <div style={{ position: "absolute", top: 70, left: 20, right: 20, zIndex: 20, background: "var(--gradient-accent)", borderRadius: 16, padding: "14px 18px", display: "flex", alignItems: "center", gap: 10, boxShadow: "var(--shadow-lg)", animation: "dtDrop 300ms cubic-bezier(0.16,1,0.3,1)" }}>
      <IcHeart size={22} style={{ color: "#fff" }} />
      <span style={{ color: "#fff", fontWeight: 500, fontSize: 15 }}>یک مچ جدید! 🎉</span>
    </div>
  );
}
function App() {
  const [screen, setScreen] = React.useState("auth"); // auth | app
  const [tab, setTab] = React.useState("heart");
  const [chat, setChat] = React.useState(null);
  const [theme, setTheme] = React.useState("light");
  const [toast, setToast] = React.useState(false);
  const toggleTheme = () => setTheme((t) => (t === "light" ? "dark" : "light"));

  let body;
  if (screen === "auth") body = <PhoneAuth onNext={() => setScreen("app")} />;
  else if (chat) body = <Chat contact={chat} onBack={() => setChat(null)} />;
  else if (tab === "heart") body = <Discover onMatch={() => setToast(true)} />;
  else if (tab === "home") body = <Discover onMatch={() => setToast(true)} />;
  else if (tab === "chat") body = <Chats onOpen={setChat} />;
  else body = <Profile theme={theme} onToggleTheme={toggleTheme} />;

  const showTabs = screen === "app" && !chat;
  return (
    <div className={theme === "dark" ? "theme-dark" : "theme-light"} style={{ width: 390, height: 844, background: "var(--bg)", borderRadius: 44, overflow: "hidden", position: "relative", boxShadow: "0 30px 80px rgba(16,17,20,0.28)", border: "10px solid #111", transition: "background 200ms ease", display: "flex", flexDirection: "column" }}>
      <StatusBar />
      {toast && <MatchToast onClose={() => setToast(false)} />}
      <div style={{ flex: 1, minHeight: 0 }}>{body}</div>
      {showTabs && (
        <TabBar active={tab} onChange={setTab} items={[
          { key: "home", label: "خانه", icon: <IcHome /> },
          { key: "heart", label: "کشف", icon: <IcHeart /> },
          { key: "chat", label: "گفتگوها", icon: <IcChat /> },
          { key: "user", label: "پروفایل", icon: <IcUser /> },
        ]} />
      )}
    </div>
  );
}
window.App = App;
