// Shared Lucide-style outline icons (stroke 2) for the Deltalk UI kit.
// Built without JSX so the icon table parses cleanly.
const _svg = (parts) => (props) => {
  const s = (props && (props.size || props.width)) || 22;
  return React.createElement(
    "svg",
    { viewBox: "0 0 24 24", fill: "none", stroke: (props && props.stroke) || "currentColor", strokeWidth: 2, strokeLinecap: "round", strokeLinejoin: "round", width: s, height: s, style: props && props.style },
    parts.map((p, i) => React.createElement(p[0], Object.assign({ key: i }, p[1])))
  );
};
const P = (d) => ["path", { d }];
const IcHome = _svg([P("m3 9 9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"), ["polyline", { points: "9 22 9 12 15 12 15 22" }]]);
const IcHeart = _svg([P("M19 14c1.49-1.46 3-3.21 3-5.5A5.5 5.5 0 0 0 16.5 3c-1.76 0-3 .5-4.5 2-1.5-1.5-2.74-2-4.5-2A5.5 5.5 0 0 0 2 8.5c0 2.29 1.51 4.04 3 5.5l7 7Z")]);
const IcChat = _svg([P("M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z")]);
const IcUser = _svg([["circle", { cx: 12, cy: 8, r: 5 }], P("M20 21a8 8 0 0 0-16 0")]);
const IcX = _svg([P("M18 6 6 18"), P("m6 6 12 12")]);
const IcStar = _svg([["polygon", { points: "12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2" }]]);
const IcSend = _svg([P("m22 2-7 20-4-9-9-4Z"), P("M22 2 11 13")]);
const IcArrow = _svg([P("M5 12h14"), P("m12 5 7 7-7 7")]);
const IcArrowR = _svg([P("M19 12H5"), P("m12 19-7-7 7-7")]);
const IcPhone = _svg([P("M22 16.92v3a2 2 0 0 1-2.18 2 19.79 19.79 0 0 1-8.63-3.07 19.5 19.5 0 0 1-6-6 19.79 19.79 0 0 1-3.07-8.67A2 2 0 0 1 4.11 2h3a2 2 0 0 1 2 1.72c.13.96.36 1.9.7 2.81a2 2 0 0 1-.45 2.11L8.09 9.91a16 16 0 0 0 6 6l1.27-1.27a2 2 0 0 1 2.11-.45c.9.34 1.85.57 2.81.7A2 2 0 0 1 22 16.92z")]);
const IcSettings = _svg([["circle", { cx: 12, cy: 12, r: 3 }], P("M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 1 1-2.83 2.83l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 0 1-4 0v-.09A1.65 1.65 0 0 0 9 19.4a1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 1 1-2.83-2.83l.06-.06a1.65 1.65 0 0 0 .33-1.82 1.65 1.65 0 0 0-1.51-1H3a2 2 0 0 1 0-4h.09A1.65 1.65 0 0 0 4.6 9a1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 1 1 2.83-2.83l.06.06a1.65 1.65 0 0 0 1.82.33H9a1.65 1.65 0 0 0 1-1.51V3a2 2 0 0 1 4 0v.09a1.65 1.65 0 0 0 1 1.51 1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 1 1 2.83 2.83l-.06.06a1.65 1.65 0 0 0-.33 1.82V9a1.65 1.65 0 0 0 1.51 1H21a2 2 0 0 1 0 4h-.09a1.65 1.65 0 0 0-1.51 1z")]);
const IcMap = _svg([P("M20 10c0 6-8 12-8 12s-8-6-8-12a8 8 0 0 1 16 0Z"), ["circle", { cx: 12, cy: 10, r: 3 }]]);
const IcSun = _svg([["circle", { cx: 12, cy: 12, r: 4 }], P("M12 2v2M12 20v2M4.93 4.93l1.41 1.41M17.66 17.66l1.41 1.41M2 12h2M20 12h2M6.34 17.66l-1.41 1.41M19.07 4.93l-1.41 1.41")]);
const IcChevron = _svg([P("m15 18-6-6 6-6")]);
const IcBell = _svg([P("M6 8a6 6 0 0 1 12 0c0 7 3 9 3 9H3s3-2 3-9"), P("M10.3 21a1.94 1.94 0 0 0 3.4 0")]);
const IcShield = _svg([P("M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z")]);
Object.assign(window, { IcHome, IcHeart, IcChat, IcUser, IcX, IcStar, IcSend, IcArrow, IcArrowR, IcPhone, IcSettings, IcMap, IcSun, IcChevron, IcBell, IcShield });
