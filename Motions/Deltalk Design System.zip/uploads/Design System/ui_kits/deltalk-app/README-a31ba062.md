# Deltalk App — UI Kit

Interactive, high-fidelity recreation of the Deltalk mobile app (Persian, RTL, IranSans).
Composes the design-system primitives (`window.DesignSystem_a1d7f7.*`) — it does not
re-implement them.

## Flow
`index.html` boots into the auth screen, then a tabbed app:
1. **PhoneAuth** — welcome + phone-number entry.
2. **Discover** — swipeable profile cards (X / like / star); a like fires a match toast.
3. **Chats** — new-match ring rail + conversation list with unread badges.
4. **Chat** — a live conversation; type + send appends a message.
5. **Profile** — avatar, interests (chips), settings rows incl. the **dark-mode toggle**.

## Files
- `index.html` — device frame, mounts everything (load via a served preview so `_ds_bundle.js` resolves).
- `App.jsx` — orchestrator (phone frame, status bar, tab nav, chat overlay, match toast, theme state).
- `PhoneAuth.jsx`, `Discover.jsx`, `Chats.jsx`, `Chat.jsx`, `Profile.jsx` — screens.
- `icons.jsx` — Lucide-style icon table (no CDN dependency).
- `data.js` — fake Persian profiles, chats, and messages.

## Notes
- Photos are represented by gradient + initial placeholders (no real imagery was provided).
- Theme flips by toggling `theme-dark`/`theme-light` on the frame root.
- Each `text/babel` script exports its symbols to `window`; screens read primitives from
  `window.DesignSystem_a1d7f7` and icons from `window`.
