// Deltalk — Discover / swipe screen
const { Badge } = window.DesignSystem_a1d7f7;
const { IcBell, IcX, IcHeart, IcStar, IcMap } = window;
function Discover({ onMatch }) {
  const profiles = window.DT_PROFILES;
  const [idx, setIdx] = React.useState(0);
  const [leaving, setLeaving] = React.useState(null); // "like" | "nope"
  const p = profiles[idx % profiles.length];
  const act = (dir) => {
    setLeaving(dir);
    setTimeout(() => {
      setLeaving(null);
      setIdx((i) => i + 1);
      if (dir === "like") onMatch && onMatch();
    }, 260);
  };
  const transform = leaving === "like" ? "translateX(120%) rotate(12deg)" : leaving === "nope" ? "translateX(-120%) rotate(-12deg)" : "none";
  return (
    <div style={{ display: "flex", flexDirection: "column", height: "100%", background: "var(--bg)" }}>
      <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", padding: "14px var(--screen-padding)" }}>
        <img src="../../assets/logo.svg" width="30" height="30" alt="" />
        <div style={{ fontSize: 20, fontWeight: 500, color: "var(--text-primary)" }}>کشف</div>
        <div style={{ position: "relative" }}><IcBell size={22} style={{ color: "var(--text-secondary)" }} /><span style={{ position: "absolute", top: -2, insetInlineEnd: -2 }}><Badge dot /></span></div>
      </div>
      <div style={{ flex: 1, padding: "4px var(--screen-padding) 0", position: "relative" }}>
        <div style={{ position: "absolute", inset: "4px 28px 0", background: "var(--surface-card)", borderRadius: "var(--radius-card)", border: "0.5px solid var(--border-subtle)", transform: "scale(0.95) translateY(10px)" }} />
        <div style={{ position: "relative", height: "100%", borderRadius: "var(--radius-card)", overflow: "hidden", boxShadow: "var(--shadow-lg)", transition: "transform 260ms var(--ease-out)", transform }}>
          <div style={{ position: "absolute", inset: 0, background: p.grad, display: "flex", alignItems: "center", justifyContent: "center" }}>
            <span style={{ fontSize: 120, fontWeight: 900, color: "rgba(255,255,255,0.9)" }}>{p.initial}</span>
          </div>
          <div style={{ position: "absolute", left: 0, right: 0, bottom: 0, padding: 20, background: "linear-gradient(to top,rgba(0,0,0,0.72),transparent)" }}>
            <div style={{ display: "flex", alignItems: "baseline", gap: 8 }}>
              <span style={{ fontSize: 24, fontWeight: 700, color: "#fff" }}>{p.name}</span>
              <span style={{ fontSize: 20, fontWeight: 400, color: "rgba(255,255,255,0.85)" }}>{p.age}</span>
            </div>
            <div style={{ display: "flex", alignItems: "center", gap: 6, margin: "6px 0 10px", color: "rgba(255,255,255,0.9)", fontSize: 13 }}>
              <IcMap size={15} /><span>{p.city} · {p.dist}</span>
            </div>
            <div style={{ display: "flex", gap: 8, flexWrap: "wrap" }}>
              {p.tags.map((t) => <span key={t} style={{ fontSize: 12, color: "#fff", padding: "4px 12px", borderRadius: 999, background: "rgba(255,255,255,0.18)", backdropFilter: "blur(4px)" }}>{t}</span>)}
            </div>
          </div>
        </div>
      </div>
      <div style={{ display: "flex", alignItems: "center", justifyContent: "center", gap: 20, padding: "18px 0 22px" }}>
        <button onClick={() => act("nope")} style={btn("var(--bg)", "var(--border-subtle)", 60)}><IcX size={26} style={{ color: "var(--text-secondary)" }} /></button>
        <button onClick={() => act("like")} style={btn("var(--gradient-accent)", "transparent", 68)}><IcHeart size={30} style={{ color: "#fff" }} /></button>
        <button onClick={() => act("nope")} style={btn("var(--bg)", "var(--border-subtle)", 60)}><IcStar size={24} style={{ color: "var(--brand-gold)" }} /></button>
      </div>
    </div>
  );
}
function btn(bg, border, size) {
  return { width: size, height: size, borderRadius: "50%", background: bg, border: `0.5px solid ${border}`, display: "flex", alignItems: "center", justifyContent: "center", cursor: "pointer", boxShadow: "var(--shadow-md)" };
}
window.Discover = Discover;
