// Deltalk — profile & settings screen
const { Button, Chip, Switch, Avatar } = window.DesignSystem_a1d7f7;
const { IcSettings, IcSun, IcBell, IcShield, IcChevron, IcMap } = window;
function Profile({ theme, onToggleTheme }) {
  const [notif, setNotif] = React.useState(true);
  const interests = ["سفر", "قهوه", "کتاب", "موسیقی", "پیاده‌روی"];
  const [sel, setSel] = React.useState(["سفر", "قهوه", "کتاب"]);
  const toggle = (t) => setSel((s) => s.includes(t) ? s.filter((x) => x !== t) : [...s, t]);
  const Row = ({ icon, label, right }) => (
    <div style={{ display: "flex", alignItems: "center", gap: 12, padding: "14px 0", borderBottom: "0.5px solid var(--border-subtle)" }}>
      <div style={{ color: "var(--text-secondary)", display: "flex" }}>{icon}</div>
      <span style={{ flex: 1, fontSize: 15, color: "var(--text-primary)" }}>{label}</span>
      {right}
    </div>
  );
  return (
    <div style={{ height: "100%", overflowY: "auto", background: "var(--bg)" }}>
      <div style={{ padding: "20px var(--screen-padding) 0", display: "flex", flexDirection: "column", alignItems: "center", gap: 10 }}>
        <Avatar initials="ک" size={92} ring />
        <div style={{ textAlign: "center" }}>
          <div style={{ fontSize: 20, fontWeight: 700, color: "var(--text-primary)" }}>کاوه، ۲۹</div>
          <div style={{ fontSize: 13, color: "var(--text-secondary)", marginTop: 2 }}>تهران، ایران</div>
        </div>
        <div style={{ width: "100%", marginTop: 4 }}>
          <Button variant="secondary" leadingIcon={<IcSettings size={18} />}>ویرایش پروفایل</Button>
        </div>
      </div>
      <div style={{ padding: "24px var(--screen-padding) 90px" }}>
        <div style={{ fontSize: 13, fontWeight: 500, color: "var(--text-secondary)", marginBottom: 12 }}>علاقه‌مندی‌ها</div>
        <div style={{ display: "flex", flexWrap: "wrap", gap: 8, marginBottom: 24 }}>
          {interests.map((t) => <Chip key={t} selected={sel.includes(t)} onClick={() => toggle(t)}>{t}</Chip>)}
        </div>
        <div style={{ fontSize: 13, fontWeight: 500, color: "var(--text-secondary)", marginBottom: 4 }}>تنظیمات</div>
        <Row icon={<IcSun size={22} />} label="حالت تیره" right={<Switch checked={theme === "dark"} onChange={onToggleTheme} />} />
        <Row icon={<IcBell size={22} />} label="اعلان‌ها" right={<Switch checked={notif} onChange={setNotif} />} />
        <Row icon={<IcShield size={22} />} label="حریم خصوصی و امنیت" right={<IcChevron size={20} style={{ color: "var(--text-hint)" }} />} />
        <Row icon={<IcMap size={22} />} label="موقعیت مکانی" right={<span style={{ fontSize: 13, color: "var(--text-hint)" }}>تهران</span>} />
      </div>
    </div>
  );
}
window.Profile = Profile;
