// Fake Deltalk profile + conversation data (Persian).
window.DT_PROFILES = [
  { id: 1, name: "نیلوفر", age: 27, city: "تهران", dist: "۳ کیلومتر", bio: "عاشق سفر، قهوهٔ صبحگاهی و پیاده‌روی‌های طولانی.", tags: ["سفر", "قهوه", "کتاب"], grad: "linear-gradient(160deg,#FFB565,#F24C9A)", initial: "ن" },
  { id: 2, name: "آرش", age: 31, city: "اصفهان", dist: "۸ کیلومتر", bio: "معمار، دوستدار موسیقی زنده و آشپزی آخر هفته.", tags: ["موسیقی", "آشپزی", "معماری"], grad: "linear-gradient(160deg,#A780FE,#5852E4)", initial: "آ" },
  { id: 3, name: "سارا", age: 24, city: "شیراز", dist: "۱۲ کیلومتر", bio: "دانشجوی هنر، نقاشی با آبرنگ و گربه‌بازی.", tags: ["هنر", "گربه", "فیلم"], grad: "linear-gradient(160deg,#F24C9A,#BB48F8)", initial: "س" },
];
window.DT_CHATS = [
  { id: 1, name: "نیلوفر", initial: "ن", grad: "linear-gradient(160deg,#FFB565,#F24C9A)", last: "سلام! خوشحالم که آشنا شدیم 🌸", time: "۱۰:۲۴", unread: 2, online: true, isNew: true },
  { id: 2, name: "آرش", initial: "آ", grad: "linear-gradient(160deg,#A780FE,#5852E4)", last: "آخر هفته برنامه‌ای داری؟", time: "دیروز", unread: 0, online: false, isNew: false },
  { id: 3, name: "سارا", initial: "س", grad: "linear-gradient(160deg,#F24C9A,#BB48F8)", last: "این آهنگو حتماً گوش بده", time: "دیروز", unread: 0, online: true, isNew: true },
  { id: 4, name: "مریم", initial: "م", grad: "linear-gradient(160deg,#5852E4,#261D82)", last: "ممنون بابت پیشنهادت 🙏", time: "۲ روز پیش", unread: 0, online: false, isNew: false },
];
window.DT_MESSAGES = [
  { me: false, text: "سلام! پروفایلت خیلی جالب بود 😊", time: "۱۰:۱۰" },
  { me: true, text: "سلام نیلوفر، مرسی! تو هم اهل سفری؟", time: "۱۰:۱۲" },
  { me: false, text: "خیلی زیاد! آخرین سفرم شمال بود.", time: "۱۰:۱۵" },
  { me: false, text: "تو معمولاً کجا میری؟", time: "۱۰:۱۵" },
  { me: true, text: "بیشتر کویر و کوهستان. آرامشش بی‌نظیره.", time: "۱۰:۲۰" },
  { me: false, text: "سلام! خوشحالم که آشنا شدیم 🌸", time: "۱۰:۲۴" },
];
