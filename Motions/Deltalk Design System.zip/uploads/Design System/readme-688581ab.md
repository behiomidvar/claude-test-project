# Deltalk Design System (دلتاک)

Deltalk is a **Persian (Farsi) dating app for all age groups (18–60+)**. Every screen is
RTL, Persian-language, and set in the **IranSans** typeface. The brand voice is modern,
warm, trustworthy, and a little mysterious and magnetic — a place "for hearts" (جایی برای دل‌ها).

This repository is the single source of truth for Deltalk's visual language: color, type,
spacing, iconography, reusable UI components, and a full interactive mobile UI kit.

## Sources provided
- **Logo:** the icon-only mark is `assets/logo.svg` — a gold→pink→purple vertical column
  (person/heart) plus a lilac→indigo→navy chat bubble with three white dots (typing).
  Full **wordmark lockups** (icon + "دلتاک") ship in four variants, used verbatim, never
  redrawn: `assets/logo-horizontal-{light,dark}.svg` and `assets/logo-vertical-{light,dark}.svg`.
  Use the light variants on light/white surfaces, dark variants on dark surfaces.
- **Fonts:** IranSans (IRANSansMobile, No-English variants) in 6 weights, copied to
  `assets/fonts/` and declared in `tokens/fonts.css`.
- **Brand brief:** a detailed written spec (colors, type, spacing, components, motion,
  a11y). No codebase or Figma file was provided — the system is built from that brief.
- **Style reference:** Untitled UI's aesthetic (clean, minimal, soft shadows, restrained
  borders, neutral-first) guides *proportion and polish only*; Deltalk's own tokens always win.

---

## CONTENT FUNDAMENTALS
- **Language & direction:** Persian (Farsi), RTL throughout. Digits shown as Persian
  numerals (۰۱۲۳۴۵۶۷۸۹) in UI copy.
- **Voice:** warm, personal, encouraging, second person ("شما"/informal "تو" in chat).
  Speaks *to* the user, not *at* them. E.g. "به دلتاک خوش آمدید" (welcome), "پروفایل خود را کامل کنید"
  (complete your profile), "یک مچ جدید!" (a new match!).
- **Tone:** friendly and reassuring, never salesy or clinical. Short, human sentences.
- **Casing:** N/A for Persian; Latin text (rare) stays sentence case.
- **Emoji:** used *sparingly* and only where genuinely warm — a single 🌸/🎉/🙏 in chat or a
  match celebration. Never in system UI, labels, or buttons.
- **Examples:** button labels are verbs ("دریافت کد تایید", "ادامه", "ویرایش پروفایل"); hints are
  short and helpful ("کد تایید برای شماره شما پیامک شد").

## VISUAL FOUNDATIONS
- **Color:** Neutral-first, built on a **cool blue-gray ramp** (hue ≈ 218°, 50→950).
  Light theme uses the lightest step for page bg (#F8FAFC) with **pure white** cards
  (#FFFFFF); dark theme uses the darkest step for page bg (#121926) with #1D2432 cards.
  Logo-gradient colors (gold #FFB565, pink #F24C9A, purple #BB48F8, indigo #5852E4, navy
  #261D82) are **accent only** — chips-selected, tab active, badges, toggles, avatar rings,
  progress, illustrations. **Never** as a screen/card background or a primary-CTA fill.
- **Primary CTA:** the single highest-contrast solid element — near-black blue-gray (#121926,
  neutral-950) on light, inverted lightest step (#F8FAFC, neutral-50) on dark. Never gradient.
- **Type:** IranSans only. Heading 24/700, page title 20/500, body 15/400 at line-height
  1.7, caption 12/400 secondary. Weights 200–900 available.
- **Spacing:** 4px base unit; scale 4/8/12/16/20/24/32/40/48. Screen padding 20px, section
  gap 24px, card padding 16px, card-gap 12px, element gap 8px, input gap 16px.
- **Radius:** inputs 12px, buttons 16px, cards 20px, chips pill (full).
- **Backgrounds:** flat solid theme colors — no images, textures, or patterns behind UI.
  Gradients appear only as small accent fills and on media/photo overlays (a
  bottom-up black protection gradient over profile photos).
- **Cards:** card-surface fill, 20px radius, **0.5px hairline border**, 16px padding; shadow
  optional (`--shadow-md`) and used sparingly — the border does most of the work.
- **Shadows:** restrained, soft, Untitled-UI-like (`--shadow-xs`…`--shadow-lg`). Never heavy.
- **Borders:** hairline 0.5px `--border-subtle`; inputs thicken to **1.5px pink** on focus.
- **Animation:** button press scale(0.97) 120ms ease-out; screen transition slide-from-right
  250ms (RTL); theme switch cross-fade 200ms; card swipe spring ~300ms; match = confetti in
  brand colors. Easing `cubic-bezier(0.16,1,0.3,1)`.
- **Hover/press:** touch-first — press states dominate (scale-down); no desktop hover reliance.
- **Transparency/blur:** used only for on-photo chips (translucent white + backdrop blur) and
  protection gradients — not on flat UI surfaces.
- **Imagery vibe:** warm, human, saturated toward the brand's gold→pink→purple range;
  profile media uses a dark bottom gradient for text legibility.

## ICONOGRAPHY
- **Set:** Lucide (outline variant), stroke 1.5–2px, default size 22px. One library only —
  never mixed. In this system the icons used by the UI kit are hand-transcribed Lucide
  glyphs (see `ui_kits/deltalk-app/icons.jsx`) so no CDN dependency is required; consuming
  projects may instead link Lucide from CDN for the full set (same stroke/style).
- **Color:** inactive icons are `--text-secondary`/`--text-hint`. Active/branded icons use
  the pink→purple logo gradient via `GradientIcon` (SVG gradient stroke) — reserved for
  active tab, branded accents, and illustrations.
- **Emoji:** only occasional warm emoji in chat/celebration copy — not as UI icons.
- **Unicode glyphs:** not used as icons.
- **Assets:** `assets/logo.svg` (icon mark) plus four wordmark lockups
  (`logo-{horizontal,vertical}-{light,dark}.svg`). No other raster/PNG icons.

---

## Index / manifest
Root:
- `styles.css` — entry point; `@import`s every token + font file (link this one file).
- `tokens/` — `colors.css`, `typography.css`, `spacing.css`, `fonts.css`, `base.css`.
- `assets/` — `logo.svg` (icon mark), `logo-{horizontal,vertical}-{light,dark}.svg`
  (wordmark lockups), `fonts/` (IranSans .ttf ×6).
- `thumbnail.html` — homepage tile.
- `guidelines/` — foundation specimen cards (Colors, Type, Spacing, Brand).
- `SKILL.md` — Agent-Skills-compatible entry point.

Components (`window.DesignSystem_a1d7f7.*`):
- **Core** (`components/core/`): `Button`, `Input`, `Card`, `Chip`, `Switch`, `Avatar`,
  `Badge`, `GradientIcon`.
- **Navigation** (`components/navigation/`): `TabBar`.

Intentional additions (beyond the brief's named list): `Avatar`, `Badge`, and `GradientIcon`
— required by the brief's accent rules (match rings, notification badges, gradient active
icons) even though they weren't itemized as standalone components.

UI kits:
- `ui_kits/deltalk-app/` — interactive Persian dating app: auth → discover (swipe) →
  matches/chats → conversation → profile, with light/dark toggle.
